<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Chore_category extends Model
{
    //
}
