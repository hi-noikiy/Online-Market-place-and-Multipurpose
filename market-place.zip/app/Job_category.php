<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Job_category extends Model
{
    //
}
