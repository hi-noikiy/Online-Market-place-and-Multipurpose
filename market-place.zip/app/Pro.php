<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pro extends Model
{
    //
}
