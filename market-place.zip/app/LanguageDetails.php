<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LanguageDetails extends Model
{
    //
}
