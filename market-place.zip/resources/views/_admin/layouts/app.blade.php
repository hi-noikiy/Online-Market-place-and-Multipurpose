<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>@yield('title')</title>

	<!-- All Plugins Css -->
	<link rel="stylesheet" href="{{asset('_admin/assets/plugins/css/plugins.css')}}">
	<link rel="stylesheet" href="{{asset('plugins/datatables/datatables.min.css')}}">

	<!-- Custom CSS -->
	<link rel="stylesheet" href="{{asset('_admin/assets/css/style.css')}}">

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>
	<div id="wrapper" class="">
		{{--
		<div class="fakeLoader"></div> --}}
		<!-- Navigation -->
		<nav class="navbar navbar-default navbar-static-top" style="margin-bottom: 0">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				<a class="navbar-brand" href="#"><img src="{{asset('_admin/assets/img/logo.png')}}" class="img-responsive" alt="Logo"></a>
			</div>
			<!-- /.navbar-header -->

			<ul class="nav navbar-top-links navbar-left header-search-form hidden-xs">
				<li><a class="menu-brand" id="menu-toggle"><span class="ti-view-grid"></span></a></li>
				{{--
				<li class="hidden-sm hidden-xs">
					<div class="header-search-form input-group">
						<span class="input-group-addon"><span class="ti-search"></span></span>
						<input type="text" class="form-control" placeholder="Search & Enter">
					</div>
				</li> --}}
			</ul>

			<ul class="nav navbar-top-links navbar-right">
				{{--
				<li class="dropdown">
					<a class="dropdown-toggle notification-show" data-toggle="dropdown" href="#">
							<i class="ti-email"></i>
							<span class="email-notify noti-count">4</span>
						</a>
					<ul class="dropdown-menu dropdown-messages right-swip">
						<li class="external">
							<h3><span class="bold">All Messages</span></h3>
							<span class="notification-label bg-success">New 6</span>
						</li>
						<li>
							<a href="messages.html">
								<div class="message-apt">
									<div class="user-img">
										<img src="{{asset('_admin/assets/img/user-1.jpg')}}" class="img-responsive img-circle" alt="">
										<span class="profile-status online"></span>
									</div>
									<div class="message-body">
										<strong>John Smith</strong>
										<span class="pull-right text-muted">
												Just Now
											</span>
										<p>I am John Smith Ckeck My...</p>
									</div>
								</div>
							</a>
						</li>
						<li>
							<a href="messages.html">
								<div class="message-apt">
									<div class="user-img">
										<img src="{{asset('_admin/assets/img/user-2.jpg')}}" class="img-responsive img-circle" alt="">
										<span class="profile-status warning"></span>
									</div>
									<div class="message-body">
										<strong>Daniel Luke</strong>
										<span class="pull-right text-muted">
												2 Min Ago
											</span>
										<p>Can You Send Me your Bugdet...</p>
									</div>
								</div>
							</a>
						</li>
						<li>
							<a href="messages.html">
								<div class="message-apt">
									<div class="user-img">
										<img src="{{asset('_admin/assets/img/user-3.jpg')}}" class="img-responsive img-circle" alt="">
										<span class="profile-status busy"></span>
									</div>
									<div class="message-body">
										<strong>Litha Lilly</strong>
										<span class="pull-right text-muted">
												7 Min Ago
											</span>
										<p>I have Check Your Design Like...</p>
									</div>
								</div>
							</a>
						</li>
						<li>
							<a href="messages.html">
								<div class="message-apt">
									<div class="user-img">
										<img src="{{asset('_admin/assets/img/user-4.jpg')}}" class="img-responsive img-circle" alt="">
										<span class="profile-status offline"></span>
									</div>
									<div class="message-body">
										<strong>Adam Kruel</strong>
										<span class="pull-right text-muted">
												1 Hour Ago
											</span>
										<p>Heelo! I need best web design...</p>
									</div>
								</div>
							</a>
						</li>
						<li>
							<a class="text-center" href="#">
									<strong>Read All Messages</strong>
									<i class="fa fa-angle-right"></i>
								</a>
						</li>
					</ul>
					<!-- /.dropdown-messages -->
				</li> --}}
				<!-- /.dropdown -->

				{{--
				<li class="dropdown">
					<a class="dropdown-toggle notification-show" data-toggle="dropdown" href="#">
							<i class="ti-bell"></i>
							<span class="task-notify noti-count">7</span>
						</a>
					<ul class="task dropdown-menu dropdown-tasks right-swip">
						<li class="external">
							<h3><span class="bold">Show Notifications</span></h3>
							<span class="notification-label bg-success">New 4</span>
						</li>
						<li>
							<a href="#">
								<div class="task-overview">
									<div class="alpha-box alpha-a">
										<span>A</span>
									</div>
									<div class="task-detail">
										<p>Hello, I am Maryam.</p>
										<span class="task-time">2 Min Ago</span>
									</div>
								</div>
							</a>
						</li>
						<li>
							<a href="#">
								<div class="task-overview">
									<div class="alpha-box alpha-d">
										<span>D</span>
									</div>
									<div class="task-detail">
										<p>Hello, I am Maryam.</p>
										<span class="task-time">2 Min Ago</span>
									</div>
								</div>
							</a>
						</li>
						<li>
							<a href="#">
								<div class="task-overview">
									<div class="alpha-box alpha-g">
										<span>G</span>
									</div>
									<div class="task-detail">
										<p>Hello, I am Maryam.</p>
										<span class="task-time">2 Min Ago</span>
									</div>
								</div>
							</a>
						</li>
						<li>
							<a href="#">
								<div class="task-overview">
									<div class="alpha-box alpha-h">
										<span>H</span>
									</div>
									<div class="task-detail">
										<p>Hello, I am Maryam.</p>
										<span class="task-time">2 Min Ago</span>
									</div>
								</div>
							</a>
						</li>
						<li>
							<a class="text-center" href="#">
									<strong>See All Tasks</strong>
									<i class="fa fa-angle-right"></i>
								</a>
						</li>
					</ul>
					<!-- /.dropdown-tasks -->
				</li> --}}
				<!-- /.dropdown -->

				{{--
				<li class="dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" href="#">
							<i class="ti-announcement"></i>
						</a>
					<div class="dropdown-menu dropdown-grid animated flipInX">
						<a href="index.html" class="dropdown-item">
							<img src="{{asset('_admin/assets/img/dashboard.png')}}" class="img-responsive" alt="" />
								<span class="dropdown-title">Dashboard</span>
							</a>
						<a href="messages.html" class="dropdown-item">
								<img src="{{asset('_admin/assets/img/chat.png')}}" class="img-responsive" alt="" />
								<span class="dropdown-title">Chat</span>
							</a>
						<a href="settings.html" class="dropdown-item">
								<img src="{{asset('_admin/assets/img/settings.png')}}" class="img-responsive" alt="" />
								<span class="dropdown-title">Settings</span>
							</a>
						<a href="create-jobs.html" class="dropdown-item">
								<img src="{{asset('_admin/assets/img/add-job.png')}}" class="img-responsive" alt="" />
								<span class="dropdown-title">New Jobs</span>
							</a>
						<a href="freelancers.html" class="dropdown-item">
								<img src="{{asset('_admin/assets/img/freelancers.png')}}" class="img-responsive" alt="" />
								<span class="dropdown-title">Freelancers</span>
							</a>
						<a href="my-profile.html" class="dropdown-item">
								<img src="{{asset('_admin/assets/img/profile.png')}}" class="img-responsive" alt="" />
								<span class="dropdown-title">Profile</span>
							</a>
					</div>
					<!-- /.dropdown-alerts -->
				</li> --}}
				<!-- /.dropdown -->

				<li class="dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" href="#">
							<img src="{{asset('_admin/assets/img/user-1.jpg')}}" class="img-responsive img-circle" alt="user">
						</a>
					<ul class="dropdown-menu dropdown-user right-swip">
						<li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
						</li>
						{{--
						<li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a> --}}
						</li>
						<li><a href="{{url('LogOut')}}"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
						</li>

					</ul>
					<!-- /.dropdown-user -->
				</li>
				{{--
				<li><a id="right-sidebar-toggle" href="#" class="btn btn-lg toggle"><i class="spin ti-settings"></i></a></li> --}}

				<!-- /.dropdown -->
			</ul>
			<!-- /.navbar-top-links -->

			<!-- Sidebar Navigation -->
			<div class="navbar-default sidebar" role="navigation">
				<div class="sidebar-nav navbar-collapse">
					<ul class="nav" id="side-menu">

						<li class="{{Request::segment(1) === 'Dashboard' ? 'active' : null}}">
							<a href="{{url('Dashboard')}}">
								<i class="fa fa-bullseye"></i>Dashboard
							</a>
						</li>
						<li class="{{Request::segment(2) === 'Category' ? 'active' : ''}}">
							<a href="{{url('Admin/Category')}}">
								<i class="fa fa-microchip"></i>Category
							</a>
						</li>
						<li class="{{Request::segment(2) === 'Country' ? 'active' : ''}}">
							<a href="{{url('Admin/Country')}}">
								<i class="fa fa-microchip"></i>Country
							</a>
						</li>
						<li class="{{Request::segment(2) === 'Qualification' ? 'active' : ''}}">
							<a href="{{url('Admin/Qualification')}}">
								<i class="fa fa-microchip"></i>Qualification
							</a>
						</li>
						<li class="{{Request::segment(2) === 'Skills' ? 'active' : ''}}">
							<a href="{{url('Admin/Skills')}}">
								<i class="fa fa-microchip"></i>Skills
							</a>
						</li>

						{{--
						<li class="{{Request::segment(1) === 'Users' ? 'active' : null}}">
							<a href="{{url('Users')}}">
								<i class="fa fa-users"></i>Users
							</a>
						</li> --}} {{--
						<li class="{{Request::segment(1) === 'Setting' ? 'active' : null}}">
							<a href="{{url('Setting')}}">
									<i class="ti ti-settings"></i>Settings
								</a>
						</li> --}} {{--
						<li><a href="messages.html"><i class="ti ti-email"></i>Messages <b class="badge bg-purple pull-right">3</b></a></li> --}}
						{{--
						<li><a href="freelancers.html"><i class="ti ti-file"></i>freelancers</a></li> --}} {{--
						<li>
							<a href="javascript:void(0)"><i class="ti ti-user"></i>For Employer <span class="fa arrow"></span></a>
							<ul class="nav nav-second-level">
								<li>
									<a href="manage-jobs.html">Manage Jobs</a>
								</li>
								<li>
									<a href="manage-candidate.html">Manage Candidate</a>
								</li>
								<li>
									<a href="manage-freelancers.html">Manage Freelancers</a>
								</li>
								<li>
									<a href="managec-ompany.html">Manage Company</a>
								</li>
								<li>
									<a href="create-jobs.html">Create Jobs</a>
								</li>
								<li>
									<a href="add-freelancer.html">Add Freelancer</a>
								</li>
							</ul>
						</li> --}} {{--
						<li>
							<a href="javascript:void(0)"><i class="ti ti-ruler-pencil"></i>For Candidate<span class="fa arrow"></span> <b class="badge bg-success pull-right">3</b></a>
							<ul class="nav nav-second-level">
								<li>
									<a href="bookmarked-jobs.html">Bookmarked Jobs</a>
								</li>
								<li>
									<a href="manage-resumes.html">Manage Resumes</a>
								</li>
								<li>
									<a href="saved-company.html">Saved Company</a>
								</li>
								<li>
									<a href="create-resume.html">Create Resume</a>
								</li>

							</ul>
						</li> --}} {{--
						<li><a href="invoice.html"><i class="ti ti-clipboard"></i>Invoice</a></li> --}} {{--
						<li><a href="my-profile.html"><i class="ti ti-folder"></i>My Profile</a></li> --}} {{--
						<li><a href="create-membership.html"><i class="ti ti-star"></i>Create Membership</a></li> --}} {{--
						<li><a href="login.html"><i class="ti ti-shift-right"></i>Log Out</a></li> --}}
					</ul>
				</div>
				<!-- /.sidebar-collapse -->
			</div>
		</nav>
		<!-- Sidebar Navigation -->

		@yield('content')

	</div>
	<!-- /#page-wrapper -->

	<div id="sidebar-wrapper">
		<a id="right-close-sidebar-toggle" href="#" class="theme-bg btn close-toogle toggle">
				Setting Pannel <i class="ti-close"></i></a>
		<div class="right-sidebar" id="side-scroll">
			<div class="user-box">
				<div class="profile-img">
					<img src="{{asset('_admin/assets/img/user-3.jpg')}}" alt="user">
					<!-- this is blinking heartbit-->
					<div class="notify setpos"> <span class="heartbit"></span> <span class="point"></span> </div>
				</div>
				<div class="profile-text">
					<h4>Daniel Dax</h4>
					<a href="#" class="user-setting"><i class="ti-settings"></i></a>
					<a href="#" class="user-mail"><i class="ti-email"></i></a>
					<a href="#" class="user-call"><i class="ti-headphone"></i></a>
					<a href="#" class="user-logout"><i class="ti-power-off"></i></a>
				</div>
				<div class="tabbable-line">
					<ul class="nav nav-tabs ">
						<li class="active">
							<a href="#options" data-toggle="tab">
									<i class="ti-palette"></i> </a>
						</li>
						<li>
							<a href="#comments" data-toggle="tab">
									<i class="ti-bell"></i> </a>
						</li>
						<li>
							<a href="#freinds" data-toggle="tab">
									<i class="ti-comment-alt"></i> </a>
						</li>
					</ul>
					<div class="tab-content">
						<div class="tab-pane active" id="options">
							<div class="accept-request">
								<div class="friend-overview">
									<div class="friend-overview-img">
										<img src="{{asset('_admin/assets/img/user-1.jpg')}}" class="img-responsive img-circle" alt="">
										<span class="fr-user-status online"></span>
									</div>
									<div class="fr-request-detail">
										<h4>Adam Dax <span class="task-time pull-right">Just Now</span></h4>
										<p>Accept Your Friend Request</p>
									</div>
								</div>
								<div class="friend-overview">
									<div class="friend-overview-img">
										<img src="{{asset('_admin/assets/img/user-2.jpg')}}" class="img-responsive img-circle" alt="">
										<span class="fr-user-status offline"></span>
									</div>
									<div class="fr-request-detail">
										<h4>Rita Ray <span class="task-time pull-right">2 Min Ago</span></h4>
										<p>Accept Your Friend Request</p>
									</div>
								</div>
								<div class="friend-overview">
									<div class="friend-overview-img">
										<img src="{{asset('_admin/assets/img/user-3.jpg')}}" class="img-responsive img-circle" alt="">
										<span class="fr-user-status busy"></span>
									</div>
									<div class="fr-request-detail">
										<h4>Daniel Mark <span class="task-time pull-right">7 Min Ago</span></h4>
										<p>Accept Your Friend Request</p>
									</div>
								</div>
								<div class="friend-overview">
									<div class="friend-overview-img">
										<img src="{{asset('_admin/assets/img/user-4.jpg')}}" class="img-responsive img-circle" alt="">
										<span class="fr-user-status offline"></span>
									</div>
									<div class="fr-request-detail">
										<h4>Shruti Singh <span class="task-time pull-right">10 Min Ago</span></h4>
										<p>Accept Your Friend Request</p>
									</div>
								</div>
							</div>
						</div>
						<div class="tab-pane" id="comments">
							<div class="task">
								<div class="task-overview">
									<div class="alpha-box alpha-a">
										<span>A</span>
									</div>
									<div class="task-detail">
										<p>Hello, I am Maryam.</p>
										<span class="task-time">2 Min Ago</span>
									</div>
								</div>
								<div class="task-overview">
									<div class="alpha-box alpha-d">
										<span>D</span>
									</div>
									<div class="task-detail">
										<p>Hello, I am Maryam.</p>
										<span class="task-time">2 Min Ago</span>
									</div>
								</div>
								<div class="task-overview">
									<div class="alpha-box alpha-s">
										<span>S</span>
									</div>
									<div class="task-detail">
										<p>Hello, I am Maryam.</p>
										<span class="task-time">2 Min Ago</span>
									</div>
								</div>
								<div class="task-overview">
									<div class="alpha-box alpha-h">
										<span>H</span>
									</div>
									<div class="task-detail">
										<p>Hello, I am Maryam.</p>
										<span class="task-time">2 Min Ago</span>
									</div>
								</div>
								<div class="task-overview">
									<div class="alpha-box alpha-g">
										<span>G</span>
									</div>
									<div class="task-detail">
										<p>Hello, I am Maryam.</p>
										<span class="task-time">2 Min Ago</span>
									</div>
								</div>
							</div>
						</div>
						<div class="tab-pane" id="freinds">
							<div class="accept-request">
								<div class="friend-overview">
									<div class="friend-overview-img">
										<img src="{{asset('_admin/assets/img/user-1.jpg')}}" class="img-responsive img-circle" alt="">
										<span class="fr-user-status online"></span>
									</div>
									<div class="fr-request-detail">
										<h4>Adam Dax <span class="task-time pull-right">Just Now</span></h4>
										<p>Accept Your Friend Request</p>
									</div>
								</div>
								<div class="friend-overview">
									<div class="friend-overview-img">
										<img src="{{asset('_admin/assets/img/user-2.jpg')}}" class="img-responsive img-circle" alt="">
										<span class="fr-user-status offline"></span>
									</div>
									<div class="fr-request-detail">
										<h4>Rita Ray <span class="task-time pull-right">2 Min Ago</span></h4>
										<p>Accept Your Friend Request</p>
									</div>
								</div>
								<div class="friend-overview">
									<div class="friend-overview-img">
										<img src="{{asset('_admin/assets/img/user-3.jpg')}}" class="img-responsive img-circle" alt="">
										<span class="fr-user-status busy"></span>
									</div>
									<div class="fr-request-detail">
										<h4>Daniel Mark <span class="task-time pull-right">7 Min Ago</span></h4>
										<p>Accept Your Friend Request</p>
									</div>
								</div>
								<div class="friend-overview">
									<div class="friend-overview-img">
										<img src="{{asset('_admin/assets/img/user-4.jpg')}}" class="img-responsive img-circle" alt="">
										<span class="fr-user-status offline"></span>
									</div>
									<div class="fr-request-detail">
										<h4>Shruti Singh <span class="task-time pull-right">10 Min Ago</span></h4>
										<p>Accept Your Friend Request</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<footer class="footer"> ©Copyright 2018 Job Stock </footer>
	</div>
	<!-- /#wrapper -->

	<!-- jQuery -->
	<script src="{{asset('_admin/assets/plugins/js/jquery.min.js')}}"></script>
	<script src="{{asset('_admin/assets/plugins/js/bootstrap.min.js')}}"></script>
	<script src="{{asset('_admin/assets/plugins/js/metisMenu.min.js')}}"></script>
	<script src="{{asset('_admin/assets/plugins/js/jquery.slimscroll.js')}}"></script>
	<script src="{{asset('_admin/assets/plugins/js/sweetalert.js')}}"></script>
	<script src="{{asset('_admin/assets/plugins/js/datepicker.js')}}"></script>
	<script src="{{asset('_admin/assets/plugins/js/ckeditor.js')}}"></script>
	<script src="{{asset('_admin/assets/plugins/js/select2.min.js')}}"></script>
	<script src="{{asset('_admin/assets/js/loader.js')}}"></script>

	{{-- Plugins --}}
	<script src="{{asset('plugins/datatables/datatables.min.js')}}"></script>
	<script type="text/javascript" src="{{asset('js/validator.min.js')}}"></script>

	<!-- Custom Theme JavaScript -->
	<script src="{{asset('_admin/assets/js/custom.js')}}"></script>

	{{-- Ajax CSRF Handle --}}
	<script type="text/javascript">
		var baseUrl = "{{url('/')}}/";
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
	</script>

	@stack('scripts')

</body>

</html>