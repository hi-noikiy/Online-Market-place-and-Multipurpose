<!DOCTYPE html>
<html lang="en" class="theme-color-07cb79 theme-skin-light">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Resume</title>

	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic">

	<!-- Icon Fonts -->
	
	<link rel="stylesheet" type="text/css" href="{{asset('css/cv/fonts/icomoon/style.css')}}">

	<!-- Styles -->


	<link rel="stylesheet" type="text/css" href="{{asset('css/cv/js/plugins/jquery.owlcarousel/owl.carousel.css')}}">
	<link rel="stylesheet" type="text/css" href="{{asset('css/cv/js/plugins/jquery.owlcarousel/owl.theme.css')}}">
	<link rel="stylesheet" type="text/css" href="{{asset('css/cv/js/plugins/jquery.optionpanel/option-panel.css')}}">
	<link rel="stylesheet" type="text/css" href="{{asset('css/cv/style.css')}}">
	<link rel="stylesheet" type="text/css" href="{{asset('css/cv/colors/theme-color.css')}}">

	
	
</head>

<body class="home header-has-img loading">	


    <div class="wrapper">
        
        <div class="content">
            <div class="container">

				<!-- START: PAGE CONTENT -->
				<section id="about" class="section section-about">
					<div class="animate-up">
						<div class="section-box">
							<div class="profile">
								<div class="row">
									<div class="col-xs-5">
										<div class="profile-photo"><img src="img/uploads/rs-photo-v1.jpg" alt="Robert Smith"/></div>
									</div>
									<div class="col-xs-7">
										<div class="profile-info">
											<div class="profile-preword"><span>Hello</span></div>
											<h1 class="profile-title"><span>I'm</span> Beard ASMATUL</h1>
											<h2 class="profile-position">Developer and businessman</h2></div>
                                            <ul class="profile-list">
                                                <li class="clearfix">
                                                    <strong class="title">Age</strong>
                                                    <span class="cont">29</span>
                                                </li>
                                                <li class="clearfix">
                                                    <strong class="title">Address</strong>
                                                    <span class="cont">Gajipur</span>
                                                </li>
                                                <li class="clearfix">
                                                    <strong class="title">E-mail</strong>
                                                    <span class="cont"><a href="mailto:robertsmith@company.com">robertsmith@company.com</a></span>
                                                </li>
                                                <li class="clearfix">
                                                    <strong class="title">Phone</strong>
                                                    <span class="cont"><a href="tel:+12562548456">+99323232323</a></span>
                                                </li>
                                                <li class="clearfix">
                                                    <strong class="title">Freelance</strong>
                                                    <span class="cont">till April 15, 2018</span>
                                                </li>
                                                <li class="clearfix">
                                                    <strong class="title"><span class="button">Available</span></strong>
                                                    <span class="cont"><i class="rsicon rsicon-calendar"></i>till March 25, 2018</span>
                                                </li>
                                            </ul>
									</div>
								</div>
							</div>
							<div class="profile-social">
								<ul class="social">
									<li><a class="ripple-centered" href="https://www.facebook.com/" target="_blank"><i class="rsicon rsicon-facebook"></i></a></li>
									
									<li><a class="ripple-centered" href="https://www.linkedin.com/" target="_blank"><i class="rsicon rsicon-linkedin"></i></a></li>
									<li><a class="ripple-centered" href="https://plus.google.com/" target="_blank"><i class="rsicon rsicon-google-plus"></i></a></li>
									<li><a class="ripple-centered" href="https://dribbble.com/" target="_blank"><i class="rsicon rsicon-dribbble"></i></a></li>
									
								</ul>
							</div>
						</div>

                        <div class="section-txt-btn">
                            <p><a class="btn btn-lg btn-border ripple" target="_blank" href="http://dev.novembit.com/rs_card/wp-content/uploads/2015/11/test-1.pdf">Download Resume</a></p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                            proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                        </div>
					</div>	
				</section><!-- #about -->
                										
				<section id="skills" class="section section-skills">
					<div class="animate-up">
						<h2 class="section-title">Professional  Skills</h2>
						<div class="section-box">
							<div class="row">							
								<div class="col-sm-6">
									<div class="progress-bar">
										<div class="bar-data">
											<span class="bar-title">Php</span>
											<span class="bar-value">80%</span>
										</div>
										<div class="bar-line">
											<span class="bar-fill" data-width="51%"></span>
										</div>
									</div>
								</div>
								
								<div class="col-sm-6">
									<div class="progress-bar">
										<div class="bar-data">
											<span class="bar-title">JavaScript</span>
											<span class="bar-value">52%</span>
										</div>
										<div class="bar-line">
											<span class="bar-fill" data-width="67%"></span>
										</div>
									</div>
								</div>
							</div>
							
							<div class="row">							
								<div class="col-sm-6">
									<div class="progress-bar">
										<div class="bar-data">
											<span class="bar-title">Laravel</span>
											<span class="bar-value">61%</span>
										</div>
										<div class="bar-line">
											<span class="bar-fill" data-width="79%"></span>
										</div>
									</div>
								</div>
								
								<div class="col-sm-6">
									<div class="progress-bar">
										<div class="bar-data">
											<span class="bar-title">HTML & CSS</span>
											<span class="bar-value">89%</span>
										</div>
										<div class="bar-line">
											<span class="bar-fill" data-width="67%"></span>
										</div>
									</div>
								</div>
							</div>
							
							<div class="row">							
								<div class="col-sm-6">
									<div class="progress-bar">
										<div class="bar-data">
											<span class="bar-title">MySQL</span>
											<span class="bar-value">99%</span>
										</div>
										<div class="bar-line">
											<span class="bar-fill" data-width="54%"></span>
										</div>
									</div>
								</div>
								
								<div class="col-sm-6">
									<div class="progress-bar">
										<div class="bar-data">
											<span class="bar-title">Photoshop</span>
											<span class="bar-value">97%</span>
										</div>
										<div class="bar-line">
											<span class="bar-fill" data-width="80%"></span>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>	
				</section><!-- #skills -->
                
			
				
				<section id="experience" class="section section-experience">
					<div class="animate-up">
						<h2 class="section-title">Work Experience</h2>

						<div class="timeline">
							<div class="timeline-bar"></div>
							<div class="timeline-inner clearfix">
                                <div class="timeline-box timeline-box-left">
                                    <span class="dot"></span>
                                    <div class="timeline-box-inner animate-right">
                                        <span class="arrow"></span>
                                        <div class="date">2019</div>
                                        <h3>PINEAPPLE</h3>
                                        <h4>Full Stack developer</h4>
                                        <p>Worked as part of a multi-disciplinary team, carrying out ad-hoc tasks as requested by the IT Manager. Had a specific brief to ensure the websites build for customer’s precisely matched their requirements.developers and marketers.</p>
                                    </div>
                                </div>

                                <div class="timeline-box timeline-box-right">
                                    <span class="dot"></span>
                                    <div class="timeline-box-inner animate-left">
                                        <span class="arrow"></span>
                                        <div class="date">2018</div>
                                        <h3>MACROSOOFT</h3>
                                        <h4>Web Developer</h4>
                                        <p>I was responsible for working on a range of projects, designing appealing websites and interacting on a daily basis with graphic designers, back-end developers and marketers.</p>
                                    </div>
                                </div>

                                <div class="timeline-box timeline-box-left">
                                    <span class="dot"></span>
                                    <div class="timeline-box-inner animate-right">
                                        <span class="arrow"></span>
                                        <div class="date">2017-2018</div>
                                        <h3>JOOJLE</h3>
                                        <h4>Systems Analyst / Web Developer</h4>
                                        <p>Rebuilt and enhanced existing ASP B2C site with ASP.NET 2.0 Framework and tools. Technology consists of ASP.NET 2.0 (C#), IIS, Microsoft SQL Server 2005, Stored Procedures & PayPal Instant Payment Notification.</p>
                                    </div>
                                </div>

                                <div class="timeline-box timeline-box-right">
                                    <span class="dot"></span>
                                    <div class="timeline-box-inner animate-left">
                                        <span class="arrow"></span>
                                        <div class="date">2018-19</div>
                                        <h3>IBBBM</h3>
                                        <h4>Webmaster / Web Developer</h4>
                                        <p>Developed, managed, operated and promoted an Internet business.Handled customer support issues.Planned and managed business finances.</p>
                                    </div>
                                </div>

								<div class="timeline-box timeline-box-left">
									<span class="dot"></span>
									<div class="timeline-box-inner animate-right">
										<span class="arrow"></span>
										<div class="date">2019</div>
										<h3>HEADBOOK</h3>
										<h4>Intern</h4>
										<p>This was beginning of my career. Developed, managed, operated and promoted an Internet business.Handled customer support issues.</p>
									</div>
								</div>
								
							</div>
						</div>
					</div>	
				</section><!-- #experience -->
				
				<section id="education" class="section section-education">
					<div class="animate-up">
						<h2 class="section-title">Education</h2>
						<div class="timeline">
							<div class="timeline-bar"></div>
							<div class="timeline-inner clearfix">

                                <div class="timeline-box timeline-box-compact timeline-box-left">
                                    <span class="dot"></span>

                                    <div class="timeline-box-inner animate-right">
                                        <span class="arrow"></span>
                                        <div class="date"><span>2012 - 2014</span></div>
                                        <h3>Master of Information Technology</h3>
                                        <h4>MIT&T</h4>
                                    </div>
                                </div>

                                <div class="timeline-box timeline-box-compact timeline-box-right">
                                    <span class="dot"></span>

                                    <div class="timeline-box-inner animate-left">
                                        <span class="arrow"></span>
                                        <div class="date"><span>2015-2019</span></div>
                                        <h3>Bachelor Computer Engineering</h3>
                                        <h4>Harwarg Universitey</h4>
                                    </div>
                                </div>

                                <div class="timeline-box timeline-box-compact timeline-box-left">
                                    <span class="dot"></span>

                                    <div class="timeline-box-inner animate-right">
                                        <span class="arrow"></span>
                                        <div class="date"><span>2019</span></div>
                                        <h3>Certificate for courses of Computer Science</h3>
                                        <h4>Stanfoorb Universitey</h4>
                                    </div>
                                </div>

                                <div class="timeline-box timeline-box-compact timeline-box-right">
                                    <span class="dot"></span>

                                    <div class="timeline-box-inner animate-left">
                                        <span class="arrow"></span>
                                        <div class="date"><span>2017</span></div>
                                        <h3>1 week Courses of Information Systems</h3>
                                        <h4>Oxforz Universitey</h4>
                                    </div>
                                </div>
							
								<div class="timeline-box timeline-box-compact timeline-box-left">
									<span class="dot"></span>

									<div class="timeline-box-inner animate-right">
										<span class="arrow"></span>
										<div class="date"><span>2017-2019</span></div>
										<h3>Software Engineering</h3>
										<h4>Sordonne University</h4>
									</div>
								</div>
							</div>
						</div>
					</div>	
				</section><!-- #education -->
				
			
								
				<section id="references" class="section section-references">
					<div class="animate-up">
						<h2 class="section-title">My Blog</h2>
						<div class="section-box">
							<ul class="ref-slider">
								<li>
									<div class="ref-box">
										<div class="person-speech">
											<p>Angular js is the most commonly used js framework which known.</p>
										</div>
										<div class="person-info clearfix">
											<img class="person-img" src="img/uploads/rs-avatar-60x60.jpg" alt="Headshot">
											
										</div>
									</div>
								</li>
								<li>
									<div class="ref-box">
										<div class="person-speech">
											<p>Vue js most commonly used js framework.</p>
										</div>
										<div class="person-info clearfix">
											<img class="person-img" src="img/uploads/rs-avatar-60x60.jpg" alt="Headshot">
											
										</div>
									</div>
								</li>
								<li>
									<div class="ref-box">
										<div class="person-speech">
											<p>Only AE is known for professional works and activities.</p>
										</div>
										<div class="person-info clearfix">
											<img class="person-img" src="img/uploads/rs-avatar-60x60.jpg" alt="Headshot">
											
										</div>
									</div>
								</li>
							</ul>
							<div class="ref-slider-nav">
								<span id="ref-slider-prev" class="slider-prev"></span>
								<span id="ref-slider-next" class="slider-next"></span>
							</div>
						</div>
					</div>	
				</section><!-- #references -->
			
	
				
		
				
				<section id="interests" class="section section-interests">
					<div class="animate-up">
						<h2 class="section-title">My Interests</h2>

						<div class="section-box">
							<p>I have a keen interest in photography. I was vice-president of the photography club during my time at university, 
							and during this period I organised a number of very successful exhibitions and events both on and off campus.						
							<br/>I also play the piano to grade 8 standard.</p>

							<ul class="interests-list">
								<li>
									<i class="map-icon map-icon-bicycling"></i>
									<span>Bicycling</span>
								</li>
								<li>
									<i class="map-icon map-icon-movie-theater"></i>
									<span>Watch Movies</span>
								</li>
								<li>
									<i class="map-icon map-icon-ice-skating"></i>
									<span>Skating</span>
								</li>
								<li>
									<i class="map-icon map-icon-shopping-mall"></i>
									<span>Shopping</span>
								</li>
								<li>
									<i class="map-icon map-icon-tennis"></i>
									<span>Playing Tennis</span>
								</li>
								<li>
									<i class="map-icon map-icon-bowling-alley"></i>
									<span>Playing Bowling</span>
								</li>
								<li>
									<i class="map-icon map-icon-swimming"></i>
									<span>Swimming</span>
								</li>
							</ul>
						</div>
					</div>	
				</section><!-- #interests -->
				
				<section id="calendar" class="section section-calendar">
					<div class="animate-up">
						<h2 class="section-title">Availability Calendar</h2>

						<div class="calendar-busy" data-weekstart="monday">
							<div class="calendar-today" style="background-image: url('img/uploads/rs-calendar-cover.jpg')">
								<div class="valign-outer">
									<div class="valign-middle">
										<div class="valign-inner">
											<div class="date">
												<span class="day"></span>
												<span class="month"></span>
											</div>
											<div class="week-day"></div>
										</div>
									</div>
								</div>
							</div>

							<div class="calendar-cont">
								<div class="calendar-header">
									<div class="calendar-nav">
										<span class="active-date"><span class="active-month"></span><span class="active-year"></span></span>
										<a class="calendar-prev ripple-centered" title="Prev"><i class="rsicon rsicon-chevron_left"></i></a>
										<a class="calendar-next ripple-centered" title="Next"><i class="rsicon rsicon-chevron_right"></i></a>
									</div>
								</div>

								<table class="calendar-body">
									<thead class="calendar-thead"></thead>
									<tbody class="calendar-tbody"></tbody>
								</table>
							</div>
						</div>
					</div>	
				</section><!-- #calendar -->
				
				<section id="contact" class="section section-contact">
					<div class="animate-up">
						<h2 class="section-title">Contact Me</h2>

						<div class="row">
							
								<div class="section-box contact-form">
									<h3>Feel free to contact me</h3>
									
									<form class="contactForm" action="https://rscard.px-lab.com/html/php/contact_form.php" method="post">
										<div class="input-field">
											<input class="contact-name" type="text" name="name"/>
											<span class="line"></span>
											<label>Name</label>
										</div>

										<div class="input-field">
											<input class="contact-email" type="email" name="email"/>
											<span class="line"></span>
											<label>Email</label>
										</div>

										<div class="input-field">
											<input class="contact-subject" type="text" name="subject"/>
											<span class="line"></span>
											<label>Subject</label>
										</div>

										<div class="input-field">
											<textarea class="contact-message" rows="4" name="message"></textarea>
											<span class="line"></span>
											<label>Message</label>
										</div>

										<span class="btn-outer btn-primary-outer ripple">
											<input class="contact-submit btn btn-lg btn-primary" type="submit" value="Send"/>
										</span>
										
										<div class="contact-response"></div>
									</form>
								
							</div>

						
						</div>
					</div>	
				</section><!-- #contact -->
				
								
			<!-- END: PAGE CONTENT -->
                
            </div><!-- .container -->
        </div><!-- .content -->

        <footer class="footer">
            <div class="footer-social">
                <ul class="social">
					<li><a class="ripple-centered" href="#" target="_blank"><i class="rsicon rsicon-facebook"></i></a></li>
					<li><a class="ripple-centered" href="#" target="_blank"><i class="rsicon rsicon-twitter"></i></a></li>
					<li><a class="ripple-centered" href="#" target="_blank"><i class="rsicon rsicon-linkedin"></i></a></li>
					<li><a class="ripple-centered" href="#" target="_blank"><i class="rsicon rsicon-google-plus"></i></a></li>
					<li><a class="ripple-centered" href="#" target="_blank"><i class="rsicon rsicon-dribbble"></i></a></li>
					<li><a class="ripple-centered" href="#" target="_blank"><i class="rsicon rsicon-instagram"></i></a></li>
				</ul>
            </div>
        </footer><!-- .footer -->
    </div><!-- .wrapper -->
	
	
    

    <!-- Scripts -->
    <script type="text/javascript" src="../../ajax.googleapis.com/ajax/libs/jquery/1/jquery.js"></script>
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBBxIKN4mTgYgTOXzxNSe67kqHr2vdDzR8"></script>
    <script type="text/javascript" src="js/site.min.js"></script>
</body>

</html>