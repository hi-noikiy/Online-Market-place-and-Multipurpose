<?php $__env->startSection('title','Chat'); ?>
<?php $__env->startSection('hed'); ?>
 <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
            'user' =>  auth()->guard('admin')->user()
        ]); ?>;
        var fetchChatURL = null;
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('message.chatJs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('message.chatCss', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section class="inner-header-title">
    <div class="container">
        <h1>Message</h1>
    </div>
</section>
 <section class="tab-sec">
    <div class="">
        <div class="col-md-12 col-sm-12">
            <div class="First-tab tool-tab">
                <ul class="nav simple nav-tabs" id="simple-design-tab">
                <li class="active"><a onclick="choseuser('1')" href="#sectionA">All</a></li>
                <li ><a href="#sectionA" onclick="choseuser('3')" >Freelancer</a></li>
                <li><a href="#sectionB" onclick="choseuser('4')" >Pros</a></li>
                <li><a href="#sectionC" onclick="choseuser('2')" >Customer</a></li>
                <li><a href="#sectionC" onclick="choseuser('6')" >Employee</a></li>
                <li><a href="#sectionC" onclick="choseuser('5')" >Job Sekeer</a></li>
                </ul>
                <div class="tab-content">
                
                    <div id="sectionA" class="tab-pane fade in active">
                        <h3>All</h3>
                        <p>All Kind of users</p>
                    </div>
                    <div id="sectionA" class="tab-pane fade in active">
                        <h3>Freelancer</h3>
                        <p>Chat with Only Freelancers</p>
                    </div>
                    
                    <div id="sectionB" class="tab-pane fade">
                        <h3>Pros</h3>
                        <p>Chat With Pros</p>
                    </div>
                    
                    <div id="sectionC" class="tab-pane fade">
                        <h3>Customers</h3>
                        <p>Chat with customers.</p>
                    </div>
                    <div id="sectionC" class="tab-pane fade">
                        <h3>Employees</h3>
                        <p>Chat with Employees.</p>
                    </div>
                    <div id="sectionC" class="tab-pane fade">
                        <h3>Job Seeker</h3>
                        <p>Chat with Jobseeker.</p>
                    </div>
                    
                </div>
            </div>
        </div>

    </div>
</section>  
 <script>
   var roomid="<?php echo e($roomId); ?>";
 </script>   

<div class="container divbox" id="appchat" >
        <div>
            
            <a style="float:right" href="<?php echo e(url('/')); ?>"><i class="fas fa-times"></i></a>
        </div> 

    <div style="float:letf" class="col-md-4 float-left chatdashboard" id="reg">

        <div class="topleftchatdiv" >
            <a class="dropdown-toggle " href="#" role="button" id="drop" data-toggle="dropdown" data-toggle="dropdown" aria-expanded="true">
               All conversation
           </a> 
           <div class="dropdown-menu " >
              
                <li class="dropdown-item "  id="unrea" aria-expanded="true" >Unread</li>
                
                
                <hr>
                
                <li class="dropdown-item" href="#">Archive</li>
                <li  class="dropdown-item "  aria-expanded="true" id="sss">Spam</li>
           
                <li class="dropdown-item" id="report" aria-expanded="true">Report</li>
                
                <hr>
                
               
                <div id="lll">

                </div>

            </div>
            <input type="text" placeholder="Search with name" class="form-controller" id="search" name="search"></input>

           
           
            <div id="spambody" >
    
            </div >
            
            <div id="unread" >
            
            </div>
            
            <div id="reportbody" >
            
            </div>
            
            <div id="indeviduallevelsearch">

            </div>
           
            <table class="table table-bordered table-hover text-success" >
           
              
                <tbody id="tbod">
        
                </tbody>
              
            </table>

        </div>
 
 
       
        <ul class="table " style="overflow-y: scroll;height:430px ;width:100%" > 
           <?php $__currentLoopData = $receivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receiver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
                <?php
                   $user=Auth::guard('admin')->user();
                    $receiverid = $receiver->id;
                   
                    if($user->id==$receiverid){
                        continue;
                    }
               
                    if($receiverid > $user->id){
                    $chatRoomId = $user->id.','.$receiver->id;
                    }
                    else{
                    $chatRoomId = $receiver->id.','.$user->id;
                    }
                    $romid=App\Chatroom::where('chatRoomId',$chatRoomId)->first();
               // echo $receiver; continue;
                    $romid=$romid->id;
               //  echo $romid; continue;
                    
                    $messagecont=App\Chatmessage::where('RoomId',$romid)
                                            ->where('readWriteStatus','!=',1)
                                            ->where('sender','!=',$user->id)
                                            ->count();
                    $message='';
                    if($messagecont>0){
                        $messageunread = App\Chatmessage::where('RoomId',$romid)
                                            ->where('readWriteStatus','!=',1)
                                            ->where('sender','!=',$user->id)
                                            ->orderBy('created_at','DESC')
                                            ->first();
                    }                     
                    else{
                        $message = App\Chatmessage::where('RoomId',$romid)->orderBy('created_at','DSEC')->first();
                        $messageunread=0;
                    }
                        
                   $timestring=' ';
                   //dd($message);
                    if($message!=''){
                         $timestring= \App\Helpers\GeneralHelper::ago($message->created_at);
                        //  $time = strtotime($message->created_at);
                        // $date= date('Y-m-d H:i:s', $time);
                        // $date = date_create($date);
                        // $nowdate = date("Y-m-d H:i:s");
                        // $nowdate = date_create($nowdate);
                        // $diff = date_diff($nowdate, $date);
                       
                        // if($diff->s > 0 && $diff->i <1  && $diff->h <= 0 && $diff->d <=0 && $diff->m <=0 && $diff->y <=0){
                        //     $timestring='just now';
                        // }elseif ($diff->i >=1  && $diff->h <= 0 && $diff->d <=0 && $diff->m <=0 && $diff->y <=0) {
                        // $timestring=$diff->i.'m  ago';
                        // }elseif ($diff->i >=1  && $diff->h >= 0 && $diff->d <=0 && $diff->m <=0 && $diff->y <=0) {
                        //     $timestring=$diff->h.'h    '.$diff->i.'m ago';
                        // }elseif($diff->h >= 0 && $diff->d >=0 && $diff->m <=0 && $diff->y <=0){
                        //     $timestring=$diff->d.'d  '.$diff->h.'h ago';
                        // }elseif($diff->d >=0 && $diff->m >=0 && $diff->y <=0){
                        //     $timestring=$diff->m.'months  '.$diff->d.'days ago';
                        // }
                        // elseif ($diff->m >=0 && $diff->y >=0) {
                        // $timestring=$diff->y.' year '.$diff->m.' months ago';
                        // }
                    }

                    if($messageunread){
                        //  $time = strtotime($messageunread->created_at);
                        // $date= date('Y-m-d H:i:s', $time);
                        // $date = date_create($date);
                        // $nowdate = date("Y-m-d H:i:s");
                        // $nowdate = date_create($nowdate);
                        // $diff = date_diff($nowdate, $date);
                       
                        // if($diff->s > 0 && $diff->i <1  && $diff->h <= 0 && $diff->d <=0 && $diff->m <=0 && $diff->y <=0){
                        //     $timestring='just now';
                        // }elseif ($diff->i >=1  && $diff->h <= 0 && $diff->d <=0 && $diff->m <=0 && $diff->y <=0) {
                        // $timestring=$diff->i.'m  ago';
                        // }elseif ($diff->i >=1  && $diff->h >= 0 && $diff->d <=0 && $diff->m <=0 && $diff->y <=0) {
                        //     $timestring=$diff->h.'h  '.$diff->i.'m ago';
                        // }elseif($diff->h >= 0 && $diff->d >=0 && $diff->m <=0 && $diff->y <=0){
                        //     $timestring=$diff->d.' days  '.$diff->h.'h ago';
                        // }elseif($diff->d >=0 && $diff->m >=0 && $diff->y <=0){
                        //     $timestring=$diff->m.' months '.$diff->d.' days ago';
                        // }
                        // elseif ($diff->m >=0 && $diff->y >=0) {
                        // $timestring=$diff->y.' year '.$diff->m.' months ago';
                        // }
                       // $timestring=App\Hel
                        $timestring= \App\Helpers\GeneralHelper::ago($messageunread->created_at);
                    }
                   
                    $starlevel=App\LevelTag::where('userleveler',$user->id)
                                    ->where('userbeenleveled',$receiver->id)
                                    ->where('value','star')->count();
                                 
                    //echo $timestring;
                    ?>
                    
                     
                    <?php if( $messageunread): ?>
                        <li class="chatliststyle"  style="overflow: auto;background:lightgray;">
                    <?php endif; ?>
                    <?php if($message): ?> 
                        <li class="chatliststyle" style="overflow: auto;">
                    <?php endif; ?>        
                            <img class="receiver-profile-image float-left" style="display:inline" src="<?php echo e(asset('/uploads/user/'.$receiver->avatar)); ?>" height="50px" width="50px"  alt="<?php echo e(asset('uploads/user/defaultpic.jpg')); ?>"  >
                            <?php if($receiver->onlineStatus==1): ?>
                                <sub class="badge badge-success" style="position: relative; right: 0%; top: 35px; color: rgb(255, 255, 255);display:inline;float:left">.</sub>

                                <?php else: ?> 
                                <sub class="badge badge-warning" style="position: relative; right: 0%; top: 35px; color: rgb(255, 255, 255);display:inline;float:left">.</sub>
                             <?php endif; ?>
                            <a  href="<?php echo e(url('privateChat/'.$chatRoomId)); ?>">
                                <div class="chatlistname" style="float:left">
                                     <h3 class="alink"  style="display:inline" >  <?php echo e($receiver->name); ?>  </h3> 
                                     <?php if($starlevel !=0): ?>
                                      <i class="far fa-star time staryellow"></i><span class="time"><?php echo e($timestring); ?></span> 
                                    <?php else: ?> 
                                    <i class="far fa-star time "><?php echo e($timestring); ?></i>
                                    <?php endif; ?> 
                                </div>
                                <br>
                                <?php if($messageunread): ?>
                                <h5 class="col-md-10 well-sm message_font" style="display:inline;" ><b><?php echo e($messageunread->message); ?></b></h5>
                                <span class="badge badge-success"><?php echo e($messagecont); ?></span>
                                <?php endif; ?>
                                <?php if($message): ?>
                                 <h5 class="message_font col-md-10 " style= "display:inline;text-align: left;overflow:auto;" ><?php echo e($message->message); ?></h5>
                                <?php endif; ?>  

                             </a>
                           
                        
                        </li>
                       
                   
                   
           
          
         
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            
             
        </ul>

    </div>
  
     <?php
       $fullurl=url()->full();
       $dashurl= url('/').'/'.'chatdashboard';
       //echo $fullurl.'<br>'.$dashurl;
       
      ?> 
      <?php if($fullurl == $dashurl): ?>
      <div class="jumbotron col-md-8 text-justify float-right message_font "><h2>Hi..  You don't start chat yet... Let's find someone and start talking <i class="far fa-smile"></i> </h2> </div>
     
      <?php endif; ?>
     
  
     <?php echo $__env->yieldContent('chatcontent'); ?>
    

      <div style="position:fixed; right:0%; bottom:0%;" id="messagepop" >

      </div>

   
</div>
   
   <!-- Scripts -->
   <script type="text/javascript">
         <?php echo $__env->yieldContent('routes'); ?>

    </script>
   
   

   

   
    <script src="<?php echo e(asset('chatjs/app.js')); ?>"></script>
     <?php echo $__env->yieldContent('script'); ?>

    <script src="https://code.jquery.com/jquery-3.3.1.min.js" ></script>
       

    
    
        <script>
        var user_type_search=0;
        function choseuser(data){
            user_type_search=data;
        }
        </script>
        <script type="text/javascript">

            $('#search').on('keyup',function(){
            
                 $value=$(this).val();
                 console.log($value);
                 $.ajax({
            
                type : 'get',
            
                 url : '<?php echo e(URL::to('chatsearch')); ?>',
            
                 data:{'search':$value,'user_type_search':user_type_search},
            
                 success:function(data){
                    console.log(data);
                  $('#tbod').html(data);
            
                 }
            
                 });
        
            })
        
        </script>
        <script type="text/javascript">
        function closeall(){
           
             location.reload();
        };
        $(document).ready(function(){
            $("#sss").click(function(){
                $.ajax({
                    type: 'get',
                    data:{'value':'Spam'}, 
                    url : '<?php echo e(URL::to('defaullevelsearch')); ?>',
                   // data:{'authid':$userid},
                    success:function(data){
                        console.log(data);
                        $('#spambody').html(data);
                      
                    }
                })
            });
            $("#report").click(function(){
                $.ajax({
                    type: 'get',
                    data:{'value':'Report'},
                    url : '<?php echo e(URL::to('defaullevelsearch')); ?>',
                   // data:{'authid':$userid},
                    success:function(data){
                        console.log(data);
                        $('#reportbody').html(data);
                      
                    }
                })
            });
            });
        </script>
        <script type="text/javascript">
        $(document).ready(function(){
            $("#drop").click(function(){
                $.ajax({
                    type: 'get',
                    url : '<?php echo e(URL::to('levelsearch')); ?>',
                    //data:{'authid':roomid },
                    success:function(data){
                     $('#lll').html(data);
                     //  console.log('success');
                    }
                })
            });
            });
        </script>
        <script>
            
            function indeviduallevelsearch(id){
                console.log(id);
                $.ajax({
                    type:'get',
                    url:'<?php echo e(url('indeviduallevelsearch')); ?>',
                    data:{'levelid':id},
                    success:function(data){
                        console.log('success');
                        console.log(data);
                        $('#indeviduallevelsearch').html(data);
                    }
                })
            };
        </script>
        <script type="text/javascript">
        $(document).click(function(){
            $("#spamclose").click(function(){
                $.ajax({
                    type: 'get',
                    url : '<?php echo e(URL::to('spamsearch')); ?>',
                    data:{'close':'close'},
                    success:function(data){
                     $('#spambody').html(data);
                     //  console.log('success');
                    }
                })
            });
            });
        </script>
         <script type="text/javascript">
        $(document).ready(function(){
            $("#unrea").click(function(){
                //console.log('unread isie');
                $.ajax({
                    type: 'get',
                    url : '<?php echo e(URL::to('unreadsearch')); ?>',
                   data:{'authid':roomid },
                    success:function(data){
                       
                     $('#unread').html(data);
                      // console.log('success');
                    }
                })
            });
            });
        </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_html.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>