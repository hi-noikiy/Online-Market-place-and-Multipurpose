<?php $__env->startSection('content'); ?>

		<div class="wrapper">  
			
	<?php
			$job=App\Job::where('customer',$customer->id)->where('jobpro',1)->get();
			$project=App\Job::where('customer',$customer->id)->where('jobpro',0)->get();
			$review= \App\Helpers\GeneralHelper::get_total_review($user->id,2);
	?>	
			<div class="clearfix"></div>
			
			<!-- Title Header Start -->
			<section class="inner-header-title" style="background-image:url(http://via.placeholder.com/1920x850);">
				<div class="container">
					<h1>Customer Profilee</h1>
				</div>
			</section>
			<div class="clearfix"></div>
			<!-- Title Header End -->
		
		<!-- Candidate Profile Start -->
        <section class="detail-desc advance-detail-pr gray-bg">
            <div class="container white-shadow">
                <div class="row">
                    <div class="detail-pic">
										<?php if($customer->profile_image != null): ?>
												<img src="<?php echo e(asset('uploads/user/'.$customer->profile_image)); ?>" class="img" alt="" />
										<?php else: ?> 
											<img src="assets/img/can-2.png" class="img" alt="" />
										<?php endif; ?>
										
										
										</div>
                    
                </div>
				
                <div class="row bottom-mrg">
                    <div class="col-md-12 col-sm-12">
                        <div class="advance-detail detail-desc-caption">
                            <h4><?php echo e($user->name); ?></h4><span class="designation"><?php echo e($customer->designation); ?></span>
                            <ul>
                                <li><strong class="j-view"><?php echo e(count($job)); ?></strong>Job Post</li>
                                <li><strong class="j-applied"><?php echo e(count($project)); ?></strong>Project Post</li>
                                <li><strong class="j-shared"><?php echo e(count($review)); ?></strong>Review</li>
                            </ul>
                        </div>
                    </div>
                </div>
				
                <div class="row no-padd">
                    <div class="detail pannel-footer">
                        <div class="col-md-5 col-sm-5">
                            <ul class="detail-footer-social">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                              
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                
                            </ul>
                        </div>
                        
                    </div>
                </div>
				
            </div>
        </section>
		
        <section class="full-detail-description full-detail gray-bg">
            <div class="container">
                <div class="col-md-12 col-sm-12">
                    <div class="full-card">
                      <div class="deatil-tab-employ tool-tab">
							<ul class="nav simple nav-tabs" id="simple-design-tab">
								<li class="active"><a href="#about">About</a></li>
								<li><a href="#address">Address</a></li>
								<li><a href="#post-job">Job Posted</a></li>
								
							</ul>
							<!-- Start All Sec -->
							<div class="tab-content">
								<!-- Start About Sec -->
								<div id="about" class="tab-pane fade in active">
									<h3>About <?php echo e($user->name); ?></h3>
								
									<p><?php echo e($customer->long_description); ?></p>
								</div>
								<!-- End About Sec -->
								<?php
										$country=App\Country::find($customer->country_code);
								?>
								<!-- Start Address Sec -->
								<div id="address" class="tab-pane fade">
									<h3>Address Info</h3>
									<ul class="job-detail-des">
										<li><span>Address:</span><?php echo e($customer->address); ?></li>
										
										<li><span>State:</span>z<?php echo e($customer->state); ?></li>
										<?php if($country): ?>
										<li><span>Country:</span><?php echo e($country->name); ?></li>
										<?php endif; ?>
										<li><span>Zip:</span><?php echo e($customer->zip); ?></li>
										<li><span>Telephone:</span><?php echo e($user->mobile); ?></li>
									
									
									</ul>
								</div>
								<!-- End Address Sec -->
								<?php
										$task=App\Job::where('customer',$customer->id)->get();
								?>
								<!-- Start Job List -->
								<div id="post-job" class="tab-pane fade">
									<h3>You have <?php echo e(count($task)); ?> job post</h3>
									<div class="row">
										<?php if($task): ?>
										<?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php
												if($job->jobpro==0){
													$image=App\Image::where('type',7)->where('item_id',$job->id)->first();
												}elseif($job->jobpro==1){
													$image=App\Image::where('type',8)->where('item_id',$job->id)->first();
												}
										?>
										<article>
											<div class="mng-company">
												<div class="col-md-2 col-sm-2">
													<div class="mng-company-pic">
														<?php if($image): ?>
														<img src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" class="img-responsive" alt="">
														<?php else: ?> 
															<img src="" class="img-responsive" alt="">
														<?php endif; ?>
													</div>
												</div>
												
												<div class="col-md-5 col-sm-5">
													<div class="mng-company-name">
														<h4><?php echo e($job->title); ?> </h4><span class="cmp-time"><?php echo e($job->created_at); ?></span></div>
												</div>
												
												<div class="col-md-4 col-sm-4">
													<div class="mng-company-location">
														<p><i class="fa fa-map-marker"></i> <?php echo e($job->Location); ?> </p>
													</div>
												</div>
												
												<div class="col-md-1 col-sm-1">
													<div class="mng-company-action">
														
															$<?php echo e($job->min); ?> to $<?php echo e($job->max); ?>

													
													</div>
												</div>
												
											</div>
											<?php if($job->jobpro==1): ?>
											<span class="tg-themetag tg-featuretag">Job</span>
											<?php endif; ?>
											<?php if($job->jobpro==0): ?>
											<span class="tg-themetag tg-featuretag">Project</span>
											<?php endif; ?>
										</article>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									
									
									</div>
									<div class="row">
										
									</div>
								</div>
								<!-- End Job List -->
								
							
							</div>
							<!-- Start All Sec -->
						</div>  
                    </div>
                </div>
            </div>
        </section>
			<!-- Footer Section Start -->

			<div class="clearfix"></div>
			<!-- Footer Section End -->
			
			<!-- Sign Up Window Code -->
			   
		
		
			
		</div>
	<?php $__env->stopSection(); ?>

<?php echo $__env->make('_html.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>