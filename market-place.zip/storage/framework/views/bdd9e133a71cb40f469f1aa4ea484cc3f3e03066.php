<?php $__env->startSection('hed'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style1.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/response.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-blue-grey.css">
<?php $__env->stopSection(); ?>
<style>

.w3-center {
    text-align: center!important;
    float: left !important;
}
</style>


<?php
  if($user->user_type==3){
    $freelancer=App\Freelancer::where('user_id',$user->id)->first();
    $cat=App\Category::where('type',2)->get();
    $gig=App\Gig::where('freelancer_id',$freelancer->id)->get();
  } elseif ($user->user_type==4) {
    $freelancer=App\Pro::where('user_id',$user->id)->first();
     $cat=App\Category::where('type',3)->get();
    $gig=App\Gig::where('freelancer_id',$freelancer->id)->get();
  } 
$myslider=0;
?>

<!-- Page Container -->
<?php if($errors->any()): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>
	
<div class="w3-container w3-content" style="max-width:1400px;margin-top:20px">    
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->
      <div class="w3-card w3-round w3-white" id="bar">
        <div class="w3-container">
         
            <p class=""><img src="<?php echo e(asset('avatar.png')); ?>" class="wow heartBeat w3-circle" style="height:106px;width:106px;padding:5px" alt="Avatar"></p>
            <h3 class="head-type" style="font-style: bold; padding: 0;"><?php echo e($user->name); ?></h3>
            <h6 style="margin-left:2px"><u>Email</u><?php echo e($user->email); ?></h6>
            <hr>
            <div class="w3-container">
                <div style="text-align: left;color:rgb(165, 160, 160)">
                  <h6 style="margin-left:2px">Response time: <?php echo e($freelancer->response_time); ?></h6>
                  <h6 style="margin-left:2px">Recent Delivery: <?php echo e($freelancer->recent_delivery); ?></h6>
                  <h6 style="margin-left:2px">Short Description: <?php echo e($freelancer->short_description); ?></h6>
                  <hr>
                  <h6 id="rateYo"></h6>
                </div>
               

            </div>


        </div>
      
    </div>
      <br>
      
          <h6 class="widget-title">
            <span> 
              <a  href="<?php echo e(url('freelancer_edit_profile/'.urlencode(base64_encode($user->id)))); ?>">Edit Profile</a>
              
            </span>
            <span>
              <a  href="<?php echo e(url('Worker_Details/'. urlencode(base64_encode($user->id)))); ?>">See My Profile</a>
            </span>
          </h6>
     
      <br>
      
      
      <div class="w3-card w3-round w3-white" id="bar">
        <div class="w3-container">
          <h6 class="widget-title">
            <span> 
              Brief Description
            </span>
          </h6>
         
          <p>
            <?php echo e($freelancer->long_description); ?>

          </p>
          <hr>

          <h6 class="widget-title">
            <span> 
              Language
            </span>
          </h6>
         
          <p></p>
          <hr>

          <h6 class="widget-title">
            <span> 
              Education
            </span>
          </h6>
         
          <p>
            <?php
                $education=App\Education::where('user_id',$user->id)->get();
            ?>
            <?php if($education): ?>
              <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <h6 style="margin:0"><?php echo e($education->school_name); ?></h6>
               <?php
                   $qualification=App\Qualification::find($education->qualification_id);
               ?>
               <?php if($qualification): ?>
               <span style="color:rgb(165, 160, 160)"><?php echo e($qualification->name); ?></span>
             
               <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </p>
          <hr>

          

          <h6 class="widget-title">
            <span> 
              Skills
            </span>
          </h6>
          
          <p>
            <?php
                 $skill_d=App\SkillDetails::where('user_id',$user->id)->get();
            ?>
            <?php if($skill_d): ?>
             <?php $__currentLoopData = $skill_d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php
               $skill=App\Skill::find($skill_details->skill_id);
              // print_r($skill);
              // exit();
               ?> 
                <?php if($skill): ?>
                  <span class="w3-tag w3-small" id="spans"><?php echo e($skill->name); ?></span>
                <?php endif; ?>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

             
       
          </p>
           <hr>

          <h6 class="widget-title">
            <span> 
              Linked Account
            </span>
          </h6>
           
          <p>
            
          </p>
          <hr>

          <h6 class="widget-title">
            <span> 
              Certificates
            </span>
          </h6>
        
          <p></p>
        </div>
      </div>
      <br>
      
    
     
    <!-- End Left Column -->
    </div>
    
    <!-- Middle Column -->
    <div class="w3-col m9">
    
      
      
      <div class="w3-container" id="cop"><br>
         
       <h6 class="widget-title">
            <span> 
               My Gigs
            </span>
            <span class="">
              <a class="" href="<?php echo e(url('Gig/create')); ?>">Create a new</a>
            </span>
        </h6>
     

     
      <?php if($gig): ?>
        <?php $__currentLoopData = $gig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="w3-col m3" style="border:1px solid #eee;margin:4px;border-radius:8px;padding:4px">
                <div class="wow jackInTheBox w3-card-4" style="border: 1px solid #eee;border-radius: 5px;width:100%;">
                  <?php
                      $image1=App\Image::where('type',$user->user_type)->where('item_id',$gig->id)->get();
                      // print_r($image1) ;
                      // exit();
                      $myslider++;
                  ?>
                    <div class="im1">
                       <?php if($image1): ?>
                      
                      
                        <?php $__currentLoopData = $image1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                         
                            <img src="<?php echo e(asset('uploads/gig/'.$image->image)); ?>" class="mySlides<?php echo $myslider; ?>"   alt="Alps" width="100%">
                         <?php
                             break;
                         ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                       
                      <?php endif; ?>
                    </div>
                   
                <div class="w3-container w3-center">
                   <br>
                  <a>
                   
                    <img class="img" src="">
                   
                    <span class=""><?php echo e($user->name); ?> </span>
                  </a>
                  <p class="card"><?php echo e($gig->title); ?></p>
                  <i class="fas fa-star" id="star"><span style="color: black;">5.0(80)</span></i>
                  
                  
                </div>
              
              </div>
            </div>
             <script>
                // var myIndex<?php echo e($myslider); ?> = 0;
                // var cl='mySlides'+<?php echo e($myslider); ?>;
               
                // carousl<?php echo e($myslider); ?>();
                
                // function carousl<?php echo e($myslider); ?>() {
                //   var i;
                //   var x = document.getElementsByClassName(cl);
                //   // console.log(x.length);
                //    console.log(myIndex<?php echo e($myslider); ?>);
                //     myIndex<?php echo e($myslider); ?>++;
                //   for (i = 0; i < x.length; i++) {
                //    // x[i].style.display = "none";  
                //   }
                 
                //   if (myIndex<?php echo e($myslider); ?> > x.length) {myIndex = 1;}    
                //   x[myIndex<?php echo e($myslider); ?>-1].style.display = "block";  
                //   setTimeout(carousl<?php echo e($myslider); ?>, 2000); // Change image every 2 seconds
                // }
              </script>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endif; ?>
    

        
    </div>

  <div class="w3-container">
   <br>
    <h3 class="cmnt-header"> Reviews </h3>
    <hr>
  </div> 
     
  <div class="w3-container"><br>
   
      <?php
            $review= \App\Helpers\GeneralHelper::get_total_review($user->id,3);
                   
      ?>
                <div class="">

                    <!-- Single Review -->
                    <div class="">
                        <div class="review-thumb">
                            <img src="http://via.placeholder.com/180x180" class="img-responsive img-circle" alt="" />
                        </div>
                        <div class="review-detail">
                            <?php if($review): ?>
                             <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php
                                if($review->giver_type==0){
                                $giver=App\All_user::find($review->giver_id);
                                }elseif ($review->giver_type==1) {
                                    $giver=App\User::find($review->giver_id);
                                }  
                             ?>
                                <h4><?php echo e($giver->name); ?><span>at <?php echo e($review->created_at); ?></span></h4>
                            
                                
                                <p><?php echo e($review->comment); ?></p>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>    
                        </div>
                    </div>

                </div>
   
      <hr>
  </div> 
      
  
  </div>
    
  
   
  
  </div>
<script>
/* Javascript */

var ra;
window.onload=function(){
   ra=3;
   
     $.ajax({
        type:'get',
        url:'<?php echo e(url('/getstarvalue')); ?>',
        data:{'item_id':<?php echo e($user->id); ?>, 'item_type':<?php echo e($user->user_type); ?>},
        success:function(data){
           
            ra=data.number;
             console.log(ra);
        }
    })
 
$(function () {
 
  $("#rateYo").rateYo({
    rating: ra,
    readOnly: true,
    starWidth: "20px"
  });
});
}


</script>
</div>


