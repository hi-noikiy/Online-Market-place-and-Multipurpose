 
<?php $__env->startSection('title', 'Pro|Find Pro'); ?> 
<?php $__env->startSection('content'); ?>

<div class="clearfix"></div>

<!-- Title Header Start -->

<div class="clearfix"></div>
<!-- Title Header End -->


<!-- bottom form section start -->
<section class="inner-header-page">
    <div class="container">
        <form class="bt-form" id="searchForm">
            <div class="col-md-4 col-sm-6">
                <input type="text" class="form-control" name="keyword" placeholder="Keyword">
            </div>

            <div class="col-md-4 col-sm-6">
                <input type="text" class="form-control" name="skills" placeholder="Skills">
            </div>

            <div class="col-md-4 col-sm-6">
                <select class="form-control" name="category">
                        <option value="">Search By Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
            </div>

            <div class="col-md-4 col-sm-6">
                <select class="form-control" name="experience">
                          <option value="">Search By Experience</option>
                          <option value="1">1 Year</option>
                          <option value="2">2 Year</option>
                          <option value="3">3 Year</option>
                          <option value="4">4 + Year</option>
                        </select>
            </div>
            <div class="col-md-4 col-sm-6">
                <select id="location" class="form-control" name="location">
                        <option value="">Choose Location</option>
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($location->id); ?>"><?php echo e($location->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
            </div>

            <div class="col-md-4 col-sm-3">
                <input type="text" class="form-control" name="budgetFrom" placeholder="Budget From">
            </div>
            <div class="col-md-4 col-sm-3">
                <input type="text" class="form-control" name="budgetTo" placeholder="Budget To">
            </div>

            

            <div class="col-md-12 col-sm-12">
                <button type="submit" class="btn btn-primary form-control">Search For Pro</button>
            </div>
        </form>
    </div>
</section>
<!-- Bottom Search Form Section End -->
<div class="clearfix"></div>
<!-- Bottom Search Form Section End -->


<!-- Accordion Design Start -->
<section class="accordion">
    <div class="container">
        <div class="row" id="proList">
            <?php echo $__env->make('_html.ajax.ajaxPro', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

</section>
<!-- Accordion Design End -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).on('click', '.pagination a', function(event) {
        event.preventDefault();
        var page = $(this).attr('href').split('page=')[1];
        paginageData(page);
    });

    function paginageData(page) {
        $.ajax({
            type: 'POST',
            url: baseUrl + "Customer/ReadPro?page=" + page,
            success: function(data) {
                $('#proList').html(data);
            }
        });
    }

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('_html.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>