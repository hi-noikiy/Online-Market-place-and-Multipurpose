
<div class="alert alert-info">
    <b>Total <?php echo e($jobs->total()); ?> Jobs Found.</b>
</div>

<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="item-click">
    <article>
        <div class="brows-job-list">
            <div class="col-md-1 col-sm-2 small-padding">
                <div class="brows-job-company-img">
                    <a href="job-detail.html">
                        <img src="http://via.placeholder.com/150x150" class="img-responsive" alt="" />
                    </a>
                </div>
            </div>
            <div class="col-md-6 col-sm-5">
                <div class="brows-job-position">
                    

                    <h3><?php echo e($job->title); ?></h3>

                    <p>
                        <span><?php echo e($job->user_name); ?></span><span class="brows-job-sallery">
                            <i class="fa fa-money"></i>$<?php echo e($job->budget); ?>

                        </span> <?php if(!empty($job->experience)): ?>
                        <span class="job-type cl-success bg-trans-success">
                            <?php echo e($job->experience); ?> Year
                        </span> <?php endif; ?>
                    </p>
                </div>
            </div>
            <div class="col-md-3 col-sm-3">
                <div class="brows-job-location">
                    <p><i class="fa fa-map-marker"></i><?php echo e($job->location.', '.$job->country); ?></p>
                </div>
            </div>
            <div class="col-md-2 col-sm-2">
                <div class="brows-job-link">
                    <a href="<?php echo e(url('JobDetails/'. urlencode(base64_encode($job->id)))); ?>" class="btn btn-default">Apply Now</a>
                </div>
            </div>
        </div>
        <span class="tg-themetag tg-featuretag"><?php echo e($job->category); ?></span>
    </article>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php echo $jobs->links(); ?>