 
<?php $__env->startSection('title', 'Find Project'); ?> 
<?php $__env->startSection('content'); ?>

<div class="clearfix"></div>

<!-- Title Header Start -->
<section class="inner-header-title" >
    <div class="container">
        <h1>Find Project</h1>
    </div>
</section>

<!-- bottom form section start -->
<section class="search-form">
    <div class="container">
        <form class="bt-form" id="searchForm">
            <div class="col-md-4 col-sm-6">
                <input type="text" class="form-control" name="keyword" placeholder="Keyword">
            </div>

            <div class="col-md-4 col-sm-6">
                <input type="text" class="form-control" name="skills" placeholder="Skills">
            </div>

            <div class="col-md-4 col-sm-6">
                <select class="form-control" name="category">
                    <option value="">Search By Category</option>
                    <?php $__currentLoopData = $response['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            

            <div class="col-md-4 col-sm-6">
                <input type="text" class="form-control" name="budgetFrom" placeholder="Budget From">
            </div>
            <div class="col-md-4 col-sm-6">
                <input type="text" class="form-control" name="budgetTo" placeholder="Budget To">
            </div>

            

            <div class="col-md-4 col-sm-6">
                <button type="submit" class="btn btn-primary" onclick="searchProject()">Search Project</button>
            </div>
        </form>
    </div>
</section>
<!-- Bottom Search Form Section End -->
<div class="clearfix"></div>
<!-- Title Header End -->

<!-- Manage Company List Start -->
<section class="manage-company gray">
    <div class="container">
        <div class="row">
            <div id="projectList">
    <?php echo $__env->make('_html.ajax.ajaxProject', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
</section>
<!-- Manage Company List End -->
<?php $__env->stopSection(); ?>
 <?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    var urlString = window.location.href;
    var url = urlString.split("/");
    length = url.length - 2;
            
    $(document).on('click', '.pagination a', function(event) {
        event.preventDefault();
        var page = $(this).attr('href').split('page=')[1];
        paginageData(page);
    });

    function paginageData(page) {
        $.ajax({
            type: 'POST',
            url: baseUrl + url[length] +"/Read?page=" + page,
            success: function(data) {
                $('#projectList').html(data);
            }
        });
    }

</script>
<script type="text/javascript" src="<?php echo e(asset('_html/pages/project.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('_html.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>