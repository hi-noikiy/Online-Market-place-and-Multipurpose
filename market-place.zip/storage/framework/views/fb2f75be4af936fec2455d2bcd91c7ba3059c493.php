<?php $__env->startSection('title','Chores And Service'); ?>
<?php $__env->startSection('content'); ?>


<?php echo $__env->make('chore.style.CSS', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('chore.style.choreContent', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="">
   <?php
       $chores=App\chore::where('type',1)->get();
       $chores_service=App\chore::where('type',2)->get();
    //    print_r($chores[0]->id);

   ?>
   
    <div class="main-div awesome">
       
       
       
         <div class="top-div">
            <h3>Find local help for your chores or trade your services</h3>
            <small>You can start by posting a chore you need done, or a service you can do for others</small>
        </div>
         <div class="post">
            <a href="<?php echo e(url('service/add')); ?>" class=" btn-post ">Post a service</a>
            <a href="<?php echo e(url('chores/add')); ?>" class="btn-post ">Post a Task</a>
        </div>
        <?php
            
        ?>
        <div class="sliderm">            
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                <?php if($chores): ?>
                <div class="carousel-inner ">
                    <?php if(count($chores)>0): ?>
                        <?php
                            $image=App\Image::where('id',$chores[0]->image_id)->first();
                            // print_r($chores[0]);
                            // exit();
                        ?>
                        <div class="carousel-item active div-slider ">
                            <img src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" class="d-block w-100 " alt="...">
                            <h6 class="c_name"><?php echo e($chores[0]->name); ?></h6>
                            <h6 class="c_price">$<?php echo e($chores[0]->price); ?></h6>
                            
                            
                        </div>
                    <?php endif; ?>    
                
                    <?php if(count($chores)>1): ?>
                        <?php
                            $image=App\Image::where('id',$chores[1]->image_id)->first();
                        ?>
                        <div class="carousel-item div-slider">
                            <img src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" class="d-block w-100" alt="...">
                            <h6 class="c_name"><?php echo e($chores[1]->name); ?></h6>
                            <h6 class="c_price">$<?php echo e($chores[1]->price); ?></h6>
                        </div>
                    <?php endif; ?>
                    
                    <?php if(count($chores)>2): ?>
                        <?php
                            $image=App\Image::where('id',$chores[2]->image_id)->first();
                            
                        ?>
                        <div class="carousel-item div-slider">
                        <img src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" class="d-block w-100" alt="...">
                            <h6 class="c_name"><?php echo e($chores[2]->name); ?></h6>
                            <h6 class="c_price">$<?php echo e($chores[2]->price); ?></h6>
                        </div>
                    <?php endif; ?>    
                </div>
                <?php endif; ?>
            </div>

            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
            <?php if($chores): ?>
            <div class="carousel-inner ">
                <?php if(count($chores)>3): ?>
                    <div class="carousel-item active div-slider">
                        <?php
                            $image=App\Image::where('id',$chores[3]->image_id)->first();
                        ?>
                        <img src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" class="d-block w-100" alt="...">
                        <h6 class="c_name"><?php echo e($chores[3]->name); ?></h6>
                        <h6 class="c_price">$<?php echo e($chores[3]->price); ?></h6>
                        
                        
                    </div>
                <?php endif; ?>

                <?php if(count($chores)>4): ?>
                    <div class="carousel-item div-slider">
                        <?php
                            $image=App\Image::where('id',$chores[4]->image_id)->first();
                        ?>
                    
                    <img src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" class="d-block w-100" alt="...">
                        <h6 class="c_name"><?php echo e($chores[4]->name); ?></h6>
                        <h6 class="c_price">$<?php echo e($chores[4]->price); ?></h6>
                    </div>
                <?php endif; ?>

                <?php if(count($chores)>5): ?>
                    <div class="carousel-item div-slider">
                    <?php
                        $image=App\Image::where('id',$chores[5]->image_id)->first();
                        
                    ?>
                    <img src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" class="d-block w-100" alt="...">
                        <h6 class="c_name"><?php echo e($chores[5]->name); ?></h6>
                        <h6 class="c_price">$<?php echo e($chores[5]->price); ?></h6>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            </div>
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
           
            <div class="carousel-inner ">
                 <?php
                    if(count($chores_service)>0){
                         $image=App\Image::where('id',$chores_service[0]->image_id)->first();
                    }else {
                        $image=null;
                    }
                    
                ?>
                <?php if($image): ?>
                <div class="carousel-item active div-slider">
                    <img src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" class="d-block w-100" alt="...">
                    <h6 class="c_name"><?php echo e($chores_service[0]->name); ?></h6>
                    <h6 class="c_price"><?php echo e($chores_service[0]->price); ?></h6>
                    
                    
                </div>
                <?php endif; ?>
               
                 <?php
                  if(count($chores_service)>1){
                         $image=App\Image::where('id',$chores_service[1]->image_id)->first();
                    }else {
                        $image=null;
                    }
                  
                    
                ?>
                 <?php if($image): ?>
                <div class="carousel-item div-slider">
                   
                <img src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" class="d-block w-100" alt="...">
                    <h6 class="c_name"><?php echo e($chores_service[1]->name); ?></h6>
                    <h6 class="c_price"><?php echo e($chores_service[1]->price); ?></h6>
                </div>
                <?php endif; ?>
                
                 <?php
                  if(count($chores_service)>2){
                         $image=App\Image::where('id',$chores_service[2]->image_id)->first();
                    }else {
                        $image=null;
                    }
                   
                ?>
                <?php if($image): ?>
                <div class="carousel-item div-slider">
                <img src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" class="d-block w-100" alt="...">
                    <h6 class="c_name"><?php echo e($chores_service[2]->name); ?></h6>
                    <h6 class="c_price"><?php echo e($chores_service[2]->price); ?></h6>
                </div>
                <?php endif; ?>
            </div>
           
            </div>
        </div>
    </div>
    <div class="category card">
        <div class="card-header">
             <h6 class="widget-title">
                <span> 
                Browse Category
                </span>
            </h6>
        </div>
       <div class="card-body">

       
            <ul style="list-style:none" class="card-body">
                <?php
                    $chore_category=App\Chore_category::all();
                ?>
                <?php $__currentLoopData = $chore_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chore_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li style="float:left"><i class="fas fa-plus-circle"><?php echo e($chore_category->name); ?></i></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

    </div>
   
    <div class="chore ">
     
            <h6 class="widget-title">
                <span> 
                  Latest Chores
                </span>
            </h6>
       
      
         <?php $__currentLoopData = $chores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chores): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('chores/details/'.$chores->id)); ?>">
            <div class="chore-div ">
                <?php
                    $image=App\Image::where('id',$chores->image_id)->first();
                ?>
                <img src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" class="chore-img" alt="">
                <div>
                    <?php
                        if($chores->precidance==1){
                        $p='Featured';
                        }else{
                            $p='Normal';
                        } 
                        if($chores->type==1){
                                $c='Chore';
                            }else{
                                $c='Service';
                            }
                    ?>
                    <small class="featured badge badge-success"><?php echo e($p); ?></small>
                    <small class="type badge badge-danger"><?php echo e($c); ?></small>
                
                </div>
                <h6 style="font-size: 17px;text-align: center;color: black;"><?php echo e($chores->name); ?></h6>
                <small class="price">$ <?php echo e($chores->price); ?></small>

            </div>
        </a>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
   
    <div class="chore ">
       <h6 class="widget-title">
                <span> 
                  Latest Services
                </span>
        </h6>
            <?php if($chores_service): ?>
            <?php $__currentLoopData = $chores_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chores): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('service/details/'.$chores->id)); ?>">
                <div class="chore-div ">
                    <?php
                        $image=App\Image::where('id',$chores->image_id)->first();
                    ?>
                    <img src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" class="chore-img" alt="">
                    <div>
                        <?php
                            if($chores->precidance==1){
                            $p='Featured';
                            }else{
                                $p='Normal';
                            } 
                            if($chores->type==1){
                                $c='Chore';
                            }else{
                                $c='Service';
                            }
                        ?>
                        <small class="featured badge badge-success"><?php echo e($p); ?></small>
                        <small class="type badge badge-danger"><?php echo e($c); ?></small>
                    
                    </div>
                    <h6 style="font-size: 17px;text-align: center;color: black;"><?php echo e($chores->name); ?></h6>
                    <small class="price">$ <?php echo e($chores->price); ?></small>

                </div>
            </a>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        


    </div>
   

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_html.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>