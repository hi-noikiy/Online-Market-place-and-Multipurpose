<?php $__env->startSection('chore_content'); ?>
<div class="breadcrumb-wrap">
    <div class="padd10">
        <span typeof="v:Breadcrumb">
        <a  href="<?php echo e(url('/')); ?>" class="main-home">Healthbuite</a></span> &gt; 
        <span typeof="v:Breadcrumb"><a  href="<?php echo e(url('chores/admin')); ?>" class="home">My Account</a></span>
    </div>
</div>
<div id="content" class="content-for-account  col-xs-12 col-sm-9 col-lg-9 ">
    
        <div class="my_box3">
          
                <h6 class="widget-title">
                        <span> 
                        My Active Task
                        </span>
                </h6>
          <?php
              $u=Auth::user()->id;
              $mytask=App\chore::where('creator',$u)->where('type',1)->get();
              $myservice=App\chore::where('creator',$u)->where('type',2)->get();
          ?>
          <div class="box_content" id="tasks_me"> 
              <?php if($mytask): ?>
                <?php $__currentLoopData = $mytask; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mytask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="grid_task">
        
                    <div class="task_badge_seal"></div>
                    
                    <div class="featured-one"></div>
                            
                    <div class="slider_picture">
                    <a href="<?php echo e(url('chores/details/'.$mytask->id)); ?>">
                        <?php
                            $image=App\Image::find($mytask->image_id)->first();
                        ?>
                        <img class="image_sld" src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" width="160" height="160" alt="Oil Change" />
                    </a>
                    </div>
                        
                    <div class="slider_versatile">
                        <?php echo e($mytask->name); ?><br/>
                        <span class="prcs_prcs">$ <?php echo e($mytask->price); ?></span>
                    </div>
            
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                                                    
          </div>
  
        </div>
        <div class="my_box3 last_row">
          
                     <h6 class="widget-title">
                        <span> 
                            My Active Service
                        </span>
                    </h6>
          <div class="box_content" id="services_me"> 
            <?php if($myservice): ?> 
              <?php $__currentLoopData = $myservice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myservice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                     
                <div class="grid_task">
                
                    <div class="service_badge_seal"></div>
                     <?php
                            $image=App\Image::find($myservice->image_id)->first();
                    ?>
                            
                    <div class="slider_picture">
                    <a href="<?php echo e(url('chores/details/'.$myservice->id)); ?>">
                        <img class="image_sld" src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" width="160" height="160" alt="physio" />
                    </a>
                    </div>
                    
                    <div class="slider_versatile">
                        <?php echo e($myservice->name); ?><br/>
                        <span class="prcs_prcs">$ <?php echo e($myservice->price); ?></span>
                    </div>
            
                </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
         
                                                      
          </div>
  
        </div>

    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('chore.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>