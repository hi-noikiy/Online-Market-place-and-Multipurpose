<?php $__currentLoopData = $data['revisionJobs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    if($item->freelancer_type==0){
        $proposal=App\FreelancerProjectProposal::find($item->proposal_id);
        $order=App\FreelancerProjectProposal::find($item->proposal_id)->profreeorder;
         $sender=App\User::find($order->freelancer_id);
         $freelancer=App\Freelancer::where('user_id',$sender->id)->first();
         $job=App\FreelancerProjectProposal::find($item->proposal_id)->job;
    }
    if($item->freelancer_type==1){
         $proposal=App\ProProjectProposal::find($item->proposal_id);
        $order=App\ProProjectProposal::find($item->proposal_id)->proproposal;
         $sender=App\User::find($order->freelancer_id);
         $freelancer=App\Pro::where('user_id',$sender->id)->first();
         $job=App\ProProjectProposal::find($item->proposal_id)->job;
    }
  
?>
<div class="brows-job-list">
    <div class="col-md-1 col-sm-2 small-padding">
        <div class="brows-job-company-img">
            <a href="job-detail.html"><img src="http://via.placeholder.com/150x150" class="img-responsive" alt="" /></a>
        </div>
    </div>
    <div class="col-md-6 col-sm-5">
        <div class="brows-job-position">
            <a href="#">
                <h3><?php echo e($job->title); ?></h3>
            </a>
            <p>
                <span><?php echo e($sender->name); ?></span><span class="brows-job-sallery"><i class="fa fa-money"></i>$<?php echo e($proposal->price); ?></span>
                <span class="job-type cl-success bg-trans-success"><?php echo e($job->Location); ?></span>
            </p>
        </div>
    </div>
    <div class="col-md-3 col-sm-3">
        <div class="brows-job-location">
            <?php
                $country=App\Country::find($freelancer->country_code);
            ?>
            <p><i class="fa fa-map-marker"></i><?php echo e($freelancer->address); ?>

            <?php if($country): ?>
            <?php echo e($country->name); ?>

            <?php endif; ?>
            </p>
        </div>
    </div>

    <div class="col-md-2 col-sm-2">

        
    </div>
</div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php echo $data[ 'revisionJobs']->links(); ?>