<?php $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-3 col-sm-6">
    <div class="category-box" data-aos="fade-up">
        <div class="category-desc">
            <div class="category-icon">
                <i class="<?php echo e($category->icon); ?>" aria-hidden="true"></i>
                <i class="<?php echo e($category->icon); ?> abs-icon" aria-hidden="true"></i>
            </div>

            <div class="category-detail category-desc-text">
                <h4> <a href="<?php echo e(URL::to('/JobByCategory/'.$category->slug)); ?>"><?php echo e($category->name); ?></a></h4>
                <p></p>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="col-md-12">
    <?php echo $data['categories']->links(); ?>

</div>