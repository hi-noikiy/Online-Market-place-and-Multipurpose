<style>


.div_div
{
	float:left;
	margin-left:6px;
	margin-bottom:6px
}

.padd_bots { padding-bottom:15px }

.p_nzl22
{
	display:inline-block;
	margin:auto
}

.ttstts
{
	color:#fff;
	padding:3px;
	border-radius:3px;
	background:#333;
}

.fl_o
{
	width:100%;
	margin:auto;
}

#shopping_menu { padding:0 ; margin:0 }

#shopping_menu li
{
	display:block;
	float:left;
	margin-right:6px;
}

#shopping_menu li a:link, #shopping_menu li a:visited
{
	padding:4px 6px 4px 6px;
	border:1px solid #2F9CDD
}

#shopping_menu li a:hover
{
	background: #2F9CDD;
	text-decoration:none;
	color:white
}

#shopping_menu li a.actiove
{
	background: #2F9CDD;
	text-decoration:none;
	color:white
}



.shopping_menu_dv
{
	float:left;
	height:30px
	;margin-bottom:10px;
	margin-top:10px;

}
.buyer_username_a, .seller_username_a
{
	color:#778F45	;
	float:left;
	text-align:center;
	line-height:12px;
	width:100%
}

.messaje-sent
{
		background:#A0C460;
	width:100%;
	margin-bottom:10px;
	border-radius:7px;
	-moz-border-radius:7px;
	overflow:hidden; color:#333;
}
.my-chatbox-standard
{
	background:#f0f0f0;
	width:100%;
	margin-bottom:10px;
	border-radius:7px;
	-moz-border-radius:7px;
	overflow:hidden;
	position:relative;
	min-height:80px


}

.messagine { float:left; margin-left:60px;width:570px }

.imagine
{
	float:left;

	background:#FDFBBB	; border-right:1px solid #ccc;
	border-radius: 7px 0px 0px 7px ;
	-moz-border-radius:7px 0px 0px 7px;
	left: 0; top: 0; width: 56px; height: 100%;
	position:absolute

}
.imagine-buyer
{
	background:#fff
}

.imagine-seller
{
	background:#fff
}

.messagine { font-size:14px; }

.multi_cat_placeholder_thing2
{
	width:400px; border-radius:5px; padding:7px;
	height:180px;
	border:1px solid #ccc;
	background:#f2f2f2;
	overflow:auto;
	float:left
}

.multi_cat_placeholder_thing
{
	width:500px; border-radius:5px; padding:7px;
	height:200px;
	border:1px solid #ccc;
	background:#f2f2f2;
	overflow:auto;
	float:left
}



ul.dets1
{
	list-style-type:none;
	padding:0;
	margin:0
}

ul.dets1 li
{
	padding:0;
	width:100%;
	margin:0;
	display:inline-block
}

ul.dets1 li h3
{
	width:50%;
	font-size:12px;
	float:left;
	padding:0;
	margin:0;
	font-weight:bold;
}


ul.dets1 li p
{
	width:50%;
	font-size:12px;
	float:left
}

.special_pmnts
{
	list-style-type:none;
	padding:0;
	margin:0

}

.special_pmnts li
{
	width:100%;
	padding:0;
	margin:0;
	display:inline-block;
	margin-bottom:20px
}

.special_pmnts li a.post_new_linktop_class:link, .special_pmnts li a.post_new_linktop_class:visited { width:90% }


.task_badge_seal2
{
	width:51px;
	height:52px; right:3px;
	top:3px;
	position:absolute;
	background:url('images/task_badge.png')
}

.task_badge_seal3
{
	width:51px;
	height:52px; right:0px;
	top:0px;
	position:absolute;
	background:url('images/task_badge.png')
}

.task_badge_seal
{
	width:51px;
	height:52px; right:4px;
	top:2px;
	position:absolute;
	background:url('images/task_badge.png')
}

.service_badge_seal
{
	width:51px;
	height:52px; right:4px;
	top:2px;
	position:absolute;
	background:url('images/ser_badge.png')
}

.service_badge_seal2
{
	width:51px;
	height:52px; right:3px;
	top:3px;
	position:absolute;
	background:url('images/ser_badge.png')
}

.service_badge_seal3
{
	width:51px;
	height:52px; right:0px;
	top:0px;
	position:absolute;
	background:url('images/ser_badge.png')
}

.super_em
{
	width:100%;
	margin:auto;
	font-style:italic;
	display:inline-block
}

/*-----------------------*/
.nots

{
	width:100%;
	margin-bottom:35px;
	border:1px solid #378AD8;
	background:#E1EEF9;
	border-radius:5px
}
.nots ul { list-style-type:none; padding:0; margin:0; padding:14px;  padding-bottom:6px; }
.nots ul li { width:100%; margin:0; padding:0; margin-bottom:9px; }

/*-----------------------*/
#my_bids{
	border-radius:5px
}
#my_bids tr th
{
	border-bottom:1px solid #f2f2f2;
	padding-bottom:5px;
	padding-top:5px;
	background:#f9f9f9;
	margin-bottom:1px;
}


/*------------------*/

.i_left_me
{
	float:left;;
	margin-left:2px;
}

.align_me_left{
	text-align:left !important
}

.tds1
{
	padding-left:7px;
	padding-bottom:10px
}

.search-options
{
	background:#f2f2f2;
	border-radius:5px;
	margin-top:10px !important;

	float:left !important
}

.cross_cross
{
	float:left;
	width:93%
}

.cross_cross2
{
	float:left;
	width:93%
}

.cross_cross2 .dropzone
{
	min-height:140px
}

/*----------------------------*/
.make_offer_box
{
	margin:auto;
	width:450px;
	padding:20px

}

.make_offer_ttl
{
	font-size:38px;
	margin-top:10px;
	margin-bottom:15px;
	font-family: 'Raleway', Arial, Helvetica, sans-serif;
}
.make_offer_ttl2
{
	font-size:13px;
}


.submit_offer_btn_dv
{
	margin:auto;
	display:block;
	margin-top:35px;
	margin-bottom:25px;
}

.offer_field_big
{
	margin:auto;
	width:100%;
	display:inline-block;
	font-size:20px;
	font-family: "Raleway",Arial, Helvetica, sans-serif;
	margin-top:20px;
	margin-bottom:20px;
}

.offer_field_1
{
	float:left;
	text-align:right;
	width:49%;
	padding-top:6px;

}

#bid_field
{
	font-size:17px;
	padding:8px;
	border:1px solid #dedede;
	border-radius:4px
}


.offer_field_2
{
	float:right;
	text-align:left;
	width:49%
}

/*----------------------------*/






.regular_ul li a:link, .regular_ul li a:visited
{
	padding:12px 15px;
	font-size:15px;
	color:#fff;
	border-radius: 4px;
	-webkit-border-radius: 4px;
	background:#FFB300;
	border-bottom:2px solid #D5800D;
	text-transform: uppercase;
	text-decoration:none;
	font-family:'Raleway',Arial, Helvetica, sans-serif
}

.regular_ul li a:hover
{
	background:#F5DFAF;
	color:#333;
	text-decoration:none
}


a.link_mm:link, a.link_mm:visited
{
	padding:12px 12px;
	font-size:12px;
	color:#fff;
	margin-top:10px;
	border-radius: 4px;
	-webkit-border-radius: 4px;
	background:#FFB300;
	border-bottom:4px solid #D5800D;
	text-transform: uppercase;
	text-decoration:none;
	font-family:'Raleway',Arial, Helvetica, sans-serif
}

a.link_mm:hover
{
	background:#F5DFAF;
	color:#333;
	text-decoration:none
}

/*-------------*/

a.link_mm2:link, a.link_mm2:visited
{
	padding:12px 15px;
	font-size:15px;
	color:#fff;
	border-radius: 4px;
	-webkit-border-radius: 4px;
	background:#399347;
	border-bottom:4px solid #4B7333;
	text-transform: uppercase;
	text-decoration:none;
	font-family:'Raleway',Arial, Helvetica, sans-serif
}

a.link_mm2:hover
{
	background:#88C969;
	color:#333;
	text-decoration:none
}

.user_av_1
{
	margin:auto;
	width:100%;
}

.user_av_2
{
	margin:auto;
	width:100%;
	margin-top:9px;
}

a.sh_link:link, a.sh_link:visited
{
	padding:7px;
	color:#fff;
	font-size:15px;
	font-weight:normal;
	text-transform:capitalize;
	background:#399347;
	border-radius:7px;
}

a.sh_link:hover
{
	background:#888;
	text-decoration:none;
}

.get_div
{
	margin:auto;
	width:1050px;
	border-bottom:1px solid #eee;
	padding-bottom:6px
}

/*----*/

.home_blur
{
	display:inline-block;
	background:url('images/office_blur.jpg') repeat-x;
	background-size: cover;
	width:100%;
	min-height:260px;
	margin:auto;
	position:relative	;
	box-shadow:0 4px 5px #cecece;
}

.slide_taskerdev
{
 	padding-top:50px;
	width:100%;
	margin:auto;
	text-align:center
}

.slider_task
{
	background:#fff;
	border:1px solid #ccc;
	padding:4px;
	border-radius:4px;
	margin-bottom:20px;

}

.slider_task:hover
{

	box-shadow:0 0 5px #fff
}

/*-------------------*/

.grid_task
{
	background:#f4f4f4;
	border:1px solid #dedede;
	padding:4px;
	border-radius:4px;

	float:left;
	margin:10px;
	position:relative
}

.grid_task:hover
{

	box-shadow:0 0 5px #fff
}



/*-------------------*/

.slider_picture
{
	width:100%;
	margin:auto;
	margin-bottom:10px;
}

.slider_versatile
{
	font-size: 12px;
	color:#444;
	font-family:Tahoma, Geneva, sans-serif;
	padding-bottom:15px;
	padding-top:5px
}

.slide_taskerdev2
{

}

.prcs_prcs
{
	font-size:13px;
	color:#6B8F47;
	font-weight:bold;
	font-family:'Raleway',Arial, Helvetica, sans-serif
}

.main_tagLine
{
	font-size:36px;
	color:#fff;
	font-weight:600;
	font-family:"Raleway",Tahoma, Geneva, sans-serif;
	margin-bottom:7px;

}

.sub_tagLine
{
	font-size:19px;
	color:#fff;
	font-weight:500;

	font-family:'Raleway',Arial, Helvetica, sans-serif;
	margin-bottom:30px;

}

.sub_tagLine2
{
	margin-bottom:50px;
}

.regular_ul { list-style-type:none; padding:0; margin:0 ; display:inline-block}
.regular_ul li { float:left; display:inline-block; padding:0; margin:0; margin-right:20px; }


/*-----*/


.task-details1
{
	list-style-type: none;
	overflow:hidden;
	width:270px;
	padding:0;
	margin:0;
                
}

.task-details1 li
{
	display:block;
	width:100%;
	float:left;overflow:hidden;
	padding:0px;
	margin:0px; border:0px;



}

.task-details1 li img
{
	float:left;
	margin-top:0px;
	margin-right:6px
}

.task-details1 li h3
{
	float:left;
	width:74px;
	font-size:11px;
	margin:0px;
	padding:0px;
	border:0px;
	margin-top:2px

}


.task-details1 li p
{
	margin:0px;
	float:left;
	width:170px;
	font-size:11px;
	padding-top: 2px;

}

.details_holder .task-details1_a h3 { width:80px }
.details_holder .task-details1_a p { width:150px }


.pk_lst_grd
{
	float:right;
	font-size:11px;
	padding:0px;
	margin:0
}

.marg_btm
{
	margin-bottom:15px;
}

.countdown_section
{
	float:left;	 padding-right:4px;
}
.countdown_descr { float:left;  }

#suggestionsList ul
{
	padding:0; margin:0
}

.rss_icon_div
{
	float:left;
	padding-top:5px;
}

.rss_icon_div img { border:0 }

.padded_menu
{
	margin-left:5px
}

#small_search_res {

	padding:0; margin:0;

}

#small_search_res li p { text-align:left; }

.notif_a
{
	padding:1px 4px 1px 4px;
	background:#333;
	border-radius:3px;
	color:#fff;
	font-size:11px
}

.margin_bottom_class
{
	padding-bottom:20px;
}

.my_box3 .no_border_btm
{
	border-bottom:none
}

.post .sk_sk_class
{
	width:350px
}

.awaiting_moderation
{
	font-style:italic;
	font-size:11px
}

/************************/

.xoxo
{
	list-style-type:none;
	padding:0;
	margin:0
}

.xoxo>li
{
	display: block;
	margin-bottom: 15px;
	margin-top: 0px;
	overflow:hidden
}



#right-sidebar
{
	list-style-type:none;

}

#right-sidebar>li
{
	display: block;
	margin-bottom: 15px;
	margin-top: 0px;
	overflow:hidden
}

.main-thing-menu-wrap
{
		background: #54A1E9; /* Old browsers */
		width:100%;
		margin:auto;
		/*-webkit-box-shadow: 0 3px 4px 4px #ddd;
		box-shadow: 0 3px 4px 4px #ddd;
*/
}

.main-thing-menu
{
	width:1050px;
margin :auto;
	/*	display:inline-block; */

display:inline-block;
min-height:48px;

	border-top:0;


}




	.main-thing-menu ul { list-style-type:none; padding:0; margin:0}
.main-thing-menu ul li { display:inline; float:left; padding-top:15px; padding-bottom:15px; }
.main-thing-menu ul li a:link , .main-thing-menu ul li a:visited{

	color:#fff;
	padding:15px;
	padding-left:16px;
	padding-right: 16px;
	border-right:1px solid #3491E4;
	border-left:1px solid #70B1ED;
	text-decoration:none;
	font-size:13px;
	font-family:'Open Sans',Arial, Helvetica, sans-serif;


}

.main-thing-menu ul li a.hm_cls:link, .main-thing-menu ul li a.hm_cls:visited
{ border-left:none }

.main-thing-menu ul li a:hover { background: #366BA7; text-decoration:none }


/***********************/

.content_div { margin:auto; width:960px;}
.small-padd-top { padding-top:10px; }


.clear20 {
width: 100%;
margin: auto;
height: 20px;
}

.button_mik
{
    background: -moz-linear-gradient(center top , #3878C7 0%, #4583C0 44%, #39629D 100%) repeat scroll 0 0 transparent #446FA2;
    border: 1px solid #FFFFFF;
    border-radius: 5px 5px 5px 5px;
    box-shadow: 0 1px 0 rgba(255, 255, 255, 0.3) inset, 0 0 2px rgba(255, 255, 255, 0.3) inset, 0 1px 2px rgba(0, 0, 0, 0.29);
    color: white !important;
    cursor: pointer;
    font: bold 12px/16px Arial,Helvetica,sans-serif;
    padding: 7px 15px 6px;
    text-align: center;
    text-decoration: none !important;
}

.button_mik:hover {
    opacity: 0.75;
}

#main
{
	text-align:justify;
	width:1050px;
	margin-bottom:10px;
	display:inline-block;
	margin:auto;
	margin-top:20px;


}
#wrapper
{
	width:100%;
	margin:auto;


}

.uls { list-style-type:none; padding:0; margin:0 }
.uls li { display:inline-block; margin-left:6px; margin-bottom:12px; }

#content
{
	float:left;
	box-shadow: 1px 1px green;
	height:auto;
	border-radius:5%;
}

#content_mm
{
	float:left;
	width:750px;
	padding-top:10px;
	/*overflow:hidden;*/
	height:auto;
}

.content_super_div_dns
{
	margin-bottom:20px !important;
	padding-bottom:20px !important;
	text-align:left !important;
	border-bottom:7px solid #f0f0f0;
	height:60px;
	padding-top:15px;
}

.taskerdev_single_title
{

	font-weight:bold;
	text-transform: capitalize;
	color:#333;
	display:inline-block;
	margin:auto;
	width:100%;
	margin-bottom:15px;
	padding-bottom:5px;
	font-family:"Raleway",Arial, Helvetica, sans-serif
}
.my_title_single
{
 	padding-left:0 !important;
	padding-top:15px;
	position:relative
}
.my_title_single h1
{
	padding:0;
	margin:0;
	font-size:20px;
}

.my_title_single p
{
	font-weight:normal;
	font-size:13px;
	padding:0;
	margin:0;
	padding-top:2px;
	text-transform:none
}

.featured_thing_task
{
	background:#9C0 ;
	display: inline-block;
	padding: 2px 10px 2px 10px;
	color: #fff;
	text-decoration: none;
	border-radius: 5px;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;

	margin-right:6px; font-weight:normal;
	font-size:11px;
}


.user_avatar
{

	text-align:center
}

.user_avatar_1
{

	text-align:center
}

.col-sm-4{
               text-align:center
}

.taskerdev_single_title h1
{
	padding:0; 
	margin:0;

	font-size:20px;
}
.proposal_sent{
    color: white;
    font-weight: 900;
    text-align: center;
    font-size: 21px;
}
.price_div
{
	 border-radius:3px;
	padding:30px;
	background:rgb(224, 247, 215);
	text-align:center;
	margin-bottom:15px;
	position:relative
}
.price_div:hover{
    padding:35px;
    margin-bottom:5px;
}
.detail_div
{
	 border-radius:3px;
	padding:20px;
	background:rgb(224, 247, 215);
	text-align:center;
	margin-bottom:15px;
	position:relative;
	color:#333
}

.p_nzl2{
	font-size:16px;
	font-family:'Raleway', Arial, Helvetica, sans-serif;
	paddding:0;
	margin:0;
}

.p_nzl{
	font-size:46px;
	font-family:'Raleway', Arial, Helvetica, sans-serif;
	paddding:0;
	margin:0;
	margin-bottom:10px;
}

.p_nzl .price_symbol
{
	font-size:19px;
	vertical-align: super
}

.wp-pagenavi
{
	margin-top:15px
}



.post-new3
{
	list-style-type:none;
	margin-left:20px;
	padding:0;
	margin:0;
	display:inline-block
}

.post-new3 li
{
	float:left;
	display:block;
	margin-bottom:10px;
	overflow:hidden;
	width:100%
}

.post-new3 li h2
{

	font-size:16px;
	font-family:"allerbold",Tahoma, Geneva, sans-serif
}



.post-new3 li p
{

	overflow:hidden
}





.top-links
{
	float:right;
	min-height:40px;


}

.top-links ul
{
	list-style-type:none;
	margin:0;
	margin-top:5px
}

.top-links ul li
{
	float:left;
	margin-right:4px;
	margin-left:4px;
	display:block;

}



.top-links a:link , .top-links a:visited
{

	color:#fff;
	padding:5px;
	text-decoration:none;
	padding-left:8px;
	padding-right:8px;
	font-size:12px;
	font-weight:400;
	font-family:'Open Sans',Arial, Helvetica, sans-serif;


}

.post_new_link_div
{
	float:right	;
	margin-top:28px;
	margin-left:15px;
}

a.post_new_linktop_class:link, a.post_new_linktop_class:visited
{
		border:none;
	padding: 3px 5px;
	font-size: 11px;
	color: #fff;
	border-radius: 4px;
	-webkit-border-radius: 4px;
	background: #FFB300;
	border-bottom: 2px solid #D5800D;
	text-transform: capitalize;
	text-decoration: none;
	font-family: 'Raleway',Arial, Helvetica, sans-serif;
	margin-bottom:4px;
}

a.post_new_linktop_class:hover
{
	background:#F5DFAF;
	color:#333;
	text-decoration:none
}




.featured-auctions .post { margin-top:10px }

.top-links  a:hover
{
	text-decoration:underline
}

.top-links  a.active
{
	/*color:#fff;
	background:#777 */
}

#header
{
	width:100%;
	margin:auto;
	display: inline-block;
}

#header .top-bar-bg
{
	width:100%;
	overflow:hidden;
	margin:auto;
	min-height:70px;
	padding-bottom:4px;
	background: #378AD8
}


#header .top-bar-bg .top-bar
{
	width:960px;
	height:5px;
	margin:auto;
	color:white;
}


#header .middle-header-bg
{
	width:100%;
	overflow:inherit;
	margin:auto;



}


#header .middle-header
{

float:right;
	/*margin-bottom:25px;*/
	position:relative;
	margin-left:25px;
	width:300px;
	height:36px

}

.logo-holder
{
	float:left
}

#header .bottom-header-bg
{
	width:100%;
	overflow:hidden;
	margin:auto;
	background:#6CA0DB;
	border-top:1px solid #ccc;
	border-bottom:1px solid #ccc;

}


#header .bottom-header-bg .bottom-header
{
	width:960px;
	height:60px;
	margin:auto;

}

#header #logo
{
	float:left;
	border:0px;
	padding-top:10px;
	padding-left:30px
}

/*---- tbody ------*/

tbody th { font-weight:normal }
.clear10 { width:100%;margin:auto; height:10px; }
.clear100 { width:100%;margin:auto; height:100px; }


.home-slider-bg
{

		width:100%;

	background:#954F24 url(images/bg_footer1.jpg);
	border-top:1px solid #954F24;
	border-bottom:1px solid #954F24;
	margin:auto;

	min-height:100px;
	margin-bottom:5px;
	margin-top:5px;
	-moz-box-shadow: 0 0 5px 5px #ddd;
-webkit-box-shadow: 0 0 5px 5px #ddd;
box-shadow: 0 0 5px 5px #ddd;
	text-align:center;

}

/*---- footer -----*/

#footer
{
	width:100%;
	background:  #378AD8; /* Old browsers */


	margin:auto;
	min-height:60px;
	margin-top:20px;
	text-align:center;

	border-top:25px solid #54A1E9


}

#footer a:link,#footer a:visited
{
	text-decoration:underline;
	color:#fff;
                font-size: 13px;
}

#footer a:hover
{
	text-decoration:none;
	color:#fff;
}

.widget-title {

	width: 100%;
	top: 50%;
	background: #dedede;
	height: 2px;
	left: 0;
	margin-bottom: 30px;
	display: block;
	margin-top: 20px;
	position: relative;

}

h3.menu_ttl
{
	text-align:left;
	padding-left:13px;
}

 .widget-title span {
text-transform: capitalize;
padding: 7px 12px;
border: 2px solid #dedede;
background: #fefefe;
position: relative;
margin: 0 auto;
top: -7px;
left: 30px;
color: #333;
font-weight: 600;
font-family: 'Raleway', Arial, Helvetica, sans-serif;
font-size: 15px;
border-radius: 4px;

}

 h3.menu_ttl span {
		left:0
 }


#footer-widget-area { color:#fff; margin:auto; text-align:left; display:inline-block; width:100% }
#footer-widget-area div ul li .widget-title
{
	color:#fff;
	text-align:left;
	background:none ;
	font-size:18px;
	margin-bottom:50px;
	display:inline-block;
	font-family:'Raleway',Arial, Helvetica, sans-serif
}

#colophon { color:#fff; border-top:0px; width:1050px; }

#colophon
{

	display:inline-block;

	font-family:'Raleway', Arial, Helvetica, sans-serif;
	color:#fff;
	padding-top:15px;
	margin:auto;

}



#site-info
{
	width:100%;
	margin:auto;
	border-top:1px solid #eee;
	margin-top:40px;
	margin-bottom:40px;
	overflow:hidden;
	padding-top:10px;
                font-size:13px;
}

#site-info-left
{
	float:left
}

#site-info-left h3{

	font-size:13px;
	margin:0px

}

#site-info-right
{
	float:right
               
}

/*----- ad things ---*/
.latest-posted-auctions .post
{ margin-bottom:10px; }
.post
{
	width:100%;
	margin:auto;
	overflow:hidden;
	border-bottom:1px solid #dfdfdf;
	position:relative;
	margin-bottom:10px;
	padding-bottom:10px
}

.post_grid
{
	width:23%;
	float:left; height:215px;
	margin-left:5px;
	margin-right:5px;
	overflow:hidden;
	border-bottom:1px solid #dfdfdf;
	position:relative
	/*margin-bottom:15px*/
}





.image_class2
{
	border:1px solid #ccc;
	padding:3px;
	background:#fff;
	-moz-border-radius: 5px;
	border-radius: 5px;

}

.image_class3
{
	border:1px solid #ccc;
	padding:3px;
	background:#fff;


}


#right-sidebar .widget-container, #content .widget-container, #left-sidebar .widget-container
{

	/*padding:10px;
	border:1px solid #CDCDCD;
	background:#fff;
	*/
}

/*------- POST NEW AD PAGE -------*/

#steps
{
	margin:0;
	padding:0;
	width:100%;
	height:60px;
	margin:auto;
	border-top:4px solid #54A1E9;

}

#steps ul
{
	list-style-type: none;
	margin-top:9px;
}


#steps ul li
{
	display: inline;
	list-style-type: none;
	padding:11px 30px 10px 30px;
	background:#cdcdcd;
	color:white;
	margin-right:11%;
	border-radius:0 0 5px 5px
}

#steps ul li.active_step
{

	background:#54A1E9;
	color:white;
}


.breadcrumb-wrap {  	width:99.6%;
	height:auto;
	margin:auto;
	
  }

.my_box3
{
	width:99.6%;
	height:auto;

	margin:auto;

}

.my_box3
{
	margin-bottom:1px;
}


.box_content
{
	padding-bottom:10px;
	width:100%;
}


.breadcrumb-wrap
{
     width: 100.8%;
    margin-top: 35px;
}

.last_row
{
	border-bottom:1px solid #dedede;
}


.box_title
{
	width:100%;



	top: 50%;
	background:#dedede;
	height:2px;
	left:0;
	margin-bottom:30px;
	display: block;
	margin-top:20px;
	position:relative
}

.box_title span
{
	text-transform:capitalize;
	padding:7px 12px;
	border:2px solid #d0fbb2;
	background:#b6b5df;
	position:relative;
	margin: 0 auto;
	top:-7px;
	left:30px;
	color:#333;
	font-weight:600;

		font-family:'Raleway',Arial, Helvetica, sans-serif;
	font-size:16px;
	border-radius:40px;


}

.switchers
{
	position:absolute;
	top:6px;
	right: 5px
}

.switch_view_link{
	float:left;
	font-size:12px;
	padding-right:6px;
	color:#777
}


.grid-selected {

	background: url('images/grid-lines.png') 0 0 no-repeat;
	width: 14px;
	height: 14px;
	float: left;
}

.list {
background: url('images/grid-lines.png') -19px -16px no-repeat;
width: 14px;
height: 14px;
float: right;
cursor: pointer;
margin-left:4px
}

.grid {
	background:url('images/grid-lines.png') 0 -16px no-repeat;
	width:14px;
	height:14px;
	float:left;
	cursor:pointer;
}


.list-selected {
	background:url('images/grid-lines.png') -19px 0 no-repeat;
	width:14px;
	height:14px;
	float:right;
	margin-left:4px
}

.list:hover {
		background:url('images/grid-lines.png') -19px 0 no-repeat;
}
.grid:hover {
		background:url('images/grid-lines.png') 0 0 no-repeat;
}



.auction_page_title h1 { padding:0; margin:0; font-size:20px; font-family:Verdana, Geneva, sans-serif }

.ad-page-image-holder
{
	float:left
}

.auction-page-details-holder
{
	float:right;
	width:400px
}



/* -------- start ad details -----*/

.auction-details
{
	list-style-type: none; padding: 0; margin:0;
	overflow:hidden;
	width:400px
}

.auction-details li
{
	display:block;
	width:100%;
	float:left;overflow:hidden;



}

.auction-details li img
{
	float:left;
	margin-top:2px;
	margin-right:10px
}

.auction-details li h3
{
	float:left;
	width:105px; font-weight:normal;
	margin:3px;
	font-size:14px
}

.auction-details li p
{
	margin:3px;
	float:left; font-size:14px;
	width:242px; font-weight:bold;

}


/* -------- start ad details -----*/

.auction-details1
{
	list-style-type: none; padding:0; margin:0;
	overflow:hidden;
	width:100%
}

.auction-details1 li
{
	display:block;
	width:100%;
	float:left;overflow:hidden;
	padding:0px;
	margin:0px; border:0px;



}

.auction-details1 li img
{
	float:left;
	margin-top:0px;
	margin-right:6px
}

.auction-details1 li h3
{
	float:left;
	width:65px;
	font-size:11px;
	margin:0px;
	padding:0px;
	border:0px;
	margin-top:1px

}

.auction-details1 li p
{
	margin:0px;
	float:left;
	width:150px;
	font-size:11px

}

.details_holder_grid .auction-details1 li p
{
	margin:0px;
	float:left;
	width:100%;
	font-size:11px;
	text-align:center

}


/* -------- end ad details -----*/

.labels
{
	border:2px solid #ccc;
	background:#fff;
	color:#333;
	padding:4px;
	height:auto;
	overflow:hidden
}

/*
.add-this
{
	padding-left:35px;
	padding-top:25px
}
*/



.padd10
{
	padding:10px;
	overflow:hidden


}

.padd10_a
{
	padding-bottom:10px;
	overflow:hidden


}

.padd13
{
	padding-top:16px;


}

#srch_icon
{
	margin-bottom:-11px

}

#big-search
{
	border:1px solid #f2f2f2;
	-moz-border-radius: 4px;
	border-radius: 2px;
	padding:6px;
	font-size:13px;
	width:250px; color:#888;
	font-family:Arial, Helvetica, sans-serif;



}

#big-search-select
{
	border:1px solid #777;
		-moz-border-radius: 10px;
	border-radius: 10px;
	padding:5px;
	font-size:13px;
	color:#888; margin-left:5px;
	font-family:Arial, Helvetica, sans-serif;
	width:148px;
		box-shadow:0 0 5px #888;
	-moz-box-shadow:0 0 5px #888;
	-webkit-box-shadow:0 0 5px #888;


}

#big-search-submit
{
	border:1px solid #777;
		-moz-border-radius: 10px;
	border-radius: 10px;
	padding:5px;
	font-size:13px; background:#F2C611;
	color:#333; margin-left:5px;
	font-family:Arial, Helvetica, sans-serif;

		box-shadow:0 0 5px #888;
	-moz-box-shadow:0 0 5px #888;
	-webkit-box-shadow:0 0 5px #888;


}

#big-search-submit:hover { opacity:0.8 }

.auction-saved
{
	background:#A0C956;
	border:1px solid #616D16;
	color:white;

}

.owner_act
{
	background:#CEDDBD;
	border:1px solid #71963F;
	color:#333;
	border-radius:5px;
	margin-bottom:10px

}

.stuff-not-paid
{
	border:1px solid #CE5B2B;
	background:#FBEBE1;
	border-radius:6px;
	margin-bottom:15px;
	width:95%;
}

.stuff-paid-ok
{
	border:1px solid #589643;
	background:#DFECD2;
	border-radius:6px;
	margin-bottom:15px;
	width:95%;
}

#footer-widget-area .widget-area {
float: left;


font-family:'Open Sans',Arial, Helvetica, sans-serif
}

a.top_link:link, a.top_link:visited
{
	border:1px solid #fff;
		-moz-border-radius: 10px;
	border-radius: 10px;
	padding:7px 13px 7px 13px; text-decoration:none;
	font-size:13px; background:#000;
	color:#fff; margin-left:5px;
	font-family:Arial, Helvetica, sans-serif


}

a.top_link:hover
{
	background:#82200e
}


a.nice_link:link, a.nice_link:visited
{
	border:1px solid #fff;
		-moz-border-radius: 5px;
	border-radius: 5px;
	padding:2px 6px 2px 6px; text-decoration:none;
	font-size:12px; background:#000;
	color:#fff; margin-left:2px;
	font-family:Arial, Helvetica, sans-serif


}

a.nice_link:hover
{
	background:#82200e
}


.do_input
{


	color:#666;
	-moz-border-radius: 5px;
	border-radius: 5px;
	padding:13px;
	border:1px solid #cdcdcd;
	background:#f2f2f2;
	font-family:Arial, Helvetica, sans-serif
}


.error_class_post_new
{
	background:#F9E6E6;
	border-bottom:1px solid #E25C5C	;
	padding-bottom:6px;
	padding-top:6px;
}

.isok
{
	padding:10px;
	border-radius:5px;
	border:1px solid #060;
	background:#E2EBD3
}

p.display-error-inside
{
	width:100%;
	padding: 5px 0 5px 0;
	font-size:15px;
	color:#D23E3E;
	margin:0;
	font-weight:bold;
}


.full_width_input { width:90% }
.full_width_input2
{
	min-width:250px;
}




.full_width{
	width:98%;
	float:left
}

.cross_cross
{
	float:left;
	width:100%
}

.cross_cross2
{
	float:left;
	width:100%
}

.cross_cross2 .dropzone
{
	min-height:140px
}


.post-new
{
	margin:0;
	padding:0;
	list-style-type:none;
	margin-left:20px;
	overflow:hidden
}

.post-new li
{
	float:left;
	display:block;
	margin-bottom:30px;
	overflow:hidden;
	width:100%
}

.post-new li h2
{
	float:left;
	width:100%;
	font-size:13px;
	padding:0;
	margin:0;
	font-weight:400;
	color:#000;
	padding-bottom:3px;
	font-family:'Open Sans',Arial, Helvetica, sans-serif
}

.post-new li p
{
	float:left;
	width:100%;
	overflow:hidden;
	margin:0;
	padding:0;
}

/* ------- */


.post-new2
{
	list-style-type:none;
	margin-left:20px
}

.post-new2 li
{
	float:left;
	display:block;
	margin-bottom:-10px;
	overflow:hidden;
	width:100%
}

.post-new2 li h2
{
	float:left;
	width:150px;
	font-size:15px; color:#3A8FB8;

}

.post-new2 li p
{
	float:left;
	width:700px;
	overflow:hidden
}


.image_holder_grid
{
	float:left;
	width:100%;
	text-align:center
}



.image_holder
{
	float:left;
	width:65px
}

.image_holder2
{
	float:left;
	width:65px
}

.title_holder h2
{font-family:"Trebuchet MS", Arial, Helvetica, sans-serif}

.title_holder
{
	float:left;
                width:400px;
                /*margin-bottom:10px*/


}

.title_holder_grid
{
	float:left;
	width:400px;
	text-align:center;
	margin-top:10px
	/*margin-bottom:10px*/


}

.title_holder3
{
	float:left;
	/*margin-bottom:10px*/

}


.title_holder2
{
	float:left;
	width:165px	;
	margin-bottom:0px;
	text-align:left

}

.mypostedon2 {
	font-size:11px;
	line-height:14px;
	padding-top:0px;
	margin-top:0px
}

.title_holder2 h2
{
	font-size:12px;
	font-weight:bold;
	margin-top:0px;
	margin-bottom:5px

}

.details_holder
{
	float:right;
	width:250px;
	margin-bottom:0px;
	font-size:12px;
	line-height:18px
                
}


.details_holder_grid
{
	float:left;
	width:100%	; text-align:center;
	margin-bottom:0px;
	font-size:12px;
	line-height:18px
                
}


.details_holder3
{
	float:left;
	width:300px	;
	margin-bottom:0px;
	font-size:12px;
	line-height:18px
                
}



.title_holder_grid h2
{
	font-size:15px;
	font-weight:bold;
	margin-top:0px
}

.title_holder h2
{
	font-size:15px;
	font-weight:bold;
	margin-top:0px
}

a:link, a:visited
{
	color:#378AD8;
	text-decoration:none
    ;
}

a:hover
{
	color:#1a74d3;
	text-decoration:underline
                
}

.mypostedon {
    font-size: 11px;
    text-align: left;
    width: 250px;
}

.mypostedon1{
    font-size: 11px;
    text-align: left;
    text-transform: capitalize;
    width: 250px;
}

.box_content
{
	padding-top:10px;
	line-height:18px;
	display:inline-block
}

.img_class, .image_class
{

	border:1px solid #ddd;
                border-radius: 50%;
	padding:2px;
	box-shadow:0 0 2px #dedede;
	-moz-box-shadow:0 0 2px #dedede;
	-webkit-box-shadow:0 0 2px #dedede;
	margin:2px; background:#fff;
}

.do_input_afs2 { width:150px }

.user-profile-avatar { width:150px;float:left; text-align:center; }
.user-profile-description { width:100%;float:left; }


.sml_ltrs
{
	font-size:11px;
	font-weight:normal
}

.image-gallery
{
	list-style-type: none;
	overflow:hidden; margin:0; padding:0;
	margin-left: 0px;
	text-indent: 0px;

}

.image-gallery li
{
	float:left;
	display:block;
	margin-right:5px;
	margin-left: 0px;

}
.image-gallery li img
{
	padding:2px;
	border:1px solid #dedede
}

.other-dets
{
	list-style-type:none;
	overflow:hidden; padding:0; margin:0;
	margin-bottom:10px
}

.other-dets li{
	display:inline;
	float:left;
	width:100%;
	margin:0px;
	padding:0px; border:0;
	margin-bottom:4px

}

.other-dets li img{
float:left;
margin-right:4px;


}

.other-dets li h3{
	float:left;width:70px;
	font-size:12px;
	padding:0px;
	margin:0px; padding-top:2px;
	margin-top:2px

}

.other-dets li p{
	float:left;width:150px;
	font-size:12px;
	padding:0px;
	margin:0px;
	margin-top:2px

}

/***********************************/


.other-dets5
{
	list-style-type:none; padding:0; margin:0;
	overflow:hidden;
	margin-bottom:10px
}

.other-dets5 li{
	display:inline;
	float:left;
	width:100%;
	margin:0px;
	padding:0px; border:0;
	margin-bottom:4px

}

.other-dets5 li img{
float:left;
margin-right:4px;


}

.other-dets5 li h3{
	float:left;width:70px;
	font-size:12px;
	padding:0px;
	margin:0px; padding-top:2px;
	margin-top:2px

}

.other-dets5 li p{
	float:left;width:130px;
	font-size:12px;
	padding:0px;
	margin:0px;
	margin-top:2px

}

.tags-placeholder
{
	border-top:1px solid #ddd;
	border-bottom:1px solid #ddd;
	background:#F3F4F8;
	overflow:hidden;
	padding:6px;
	margin-bottom:10px;
	box-shadow:0 0 5px #ddd;
}

.tags-placeholder .tg1 { float:left;margin-left:10px }
.tags-placeholder .tg2 { float:left; padding-top:3px }
.tags-placeholder .tg3 { float:right; width:150px; text-align:right; padding-top:3px }
.addthis_toolbox { text-align:right }
.clear5 { margin-top:10px; float:right; width:260px }

.clear10b {width:100%; margin:auto; margin-top:5px }

/*********************************/
.notif_a
{
	padding:1px 4px 1px 4px;
	background:#333;
	border-radius:3px;
	color:#fff;
	font-size:11px
}
#logins
{
	list-style:none;
	margin:20px;
                padding: 1px;
}

.mrgn_btm
{
	margin-bottom:7px;
}

#logins li
{
	display:inline
}


#logins li a:link, #logins li a:visited
{


		border:none;
	padding: 5px 8px;
	font-size: 15px;
	color: #fff;
	font-weight:600;

	border-radius: 4px;
	-webkit-border-radius: 4px;
	background: #FFB300;
	border-bottom:2px solid #D5800D;
	text-transform: capitalize;
	text-decoration: none;
	font-family: 'Raleway',Arial, Helvetica, sans-serif;

}


#logins li a:hover
{
	background:#F5DFAF;
	color:#333;
	text-decoration:none
}


#my-account-admin-menu
{
	list-style:none;
	overflow:hidden;
	margin:0px;
	padding:0;


}

#my-account-admin-menu li
{
	display:block;
	font-family:Arial, Helvetica, sans-serif;
	overflow:hidden;
	margin-bottom:0px;
	padding:0px; border:0;


}


#my-account-admin-menu li a
{
    background:rgb(82, 242, 143);
	display: inline-block;
	padding: 5px 15px 5px 15px;
	color: white;

	text-decoration: none;
	/* border-bottom:1px solid #D5800D;
	border-top:1px solid #F4B45B; */

	position: relative;
	cursor: pointer;
	margin-left:3px;
	font-size:14px;
    font-weight: 700;
	width:100%;
	text-align:left;
	margin-bottom:0px;
	text-transform:capitalize;
	font-family:'Raleway',Arial, Helvetica, sans-serif

}


#my-account-admin-menu li a:hover
{
	background:white;
	color:black;
    margin-left:5px;
	text-decoration:none

}

li.final_row_a a:link, li.final_row_a a:visited
{
	border-radius:0 0 5px 5px;
	box-shadow:0 3px 2px #ddd;
}

li.final_row_a
{
	padding-bottom:5px !important;
}



a.name_account_main
{
	font-style: oblique;
    font-family: 'Raleway',Arial, Helvetica, sans-serif;
    font-size: 21px;
    color: darkblue;
}

/* ------------------ */

#my-account-admin-menu_seller
{
	list-style:none;
	overflow:hidden;
	margin:0px;
	padding:0;


}

#my-account-admin-menu_seller li
{
	display:block;
	font-family:Arial, Helvetica, sans-serif;
	overflow:hidden;
	margin-bottom:0px;
	padding:0px; border:0;


}


#my-account-admin-menu_seller li a
{
	background:rgb(82, 242, 143);
	display: inline-block;
	padding: 5px 15px 5px 15px;
	color: white;

	text-decoration: none;
	/* border-bottom:1px solid #D5800D;
	border-top:1px solid #F4B45B; */

	position: relative;
	cursor: pointer;
	margin-left:3px;
	font-size:14px;
    font-weight: 700;
	width:100%;
	text-align:left;
	margin-bottom:0px;
	text-transform:capitalize;
	font-family:'Raleway',Arial, Helvetica, sans-serif


}


#my-account-admin-menu_seller li a:hover
{
	background:white;
    margin-left:5px;
	color:black;
	text-decoration:none

}

/* ------------------ */

#my-account-admin-menu_buyer
{
	list-style:none;
	overflow:hidden;
	margin:0px;
	padding:0


}

#my-account-admin-menu_buyer li
{
	display:block;
	font-family:Arial, Helvetica, sans-serif;
	overflow:hidden;
	margin-bottom:0px;
	padding:0px; border:0;


}

/* 
#my-account-admin-menu_buyer li a
{
	background:#E3762D ;
	display: inline-block;
	padding: 5px 15px 5px 15px;
	color: #fff;
	text-decoration: none;
	border-bottom:1px solid #BF5B1A;
	border-top:1px solid #E78747;
	position: relative;
	cursor: pointer;
	margin-left:3px;
	font-size:12px;
	width:230px;
	text-align:left;
	margin-bottom:0px;
	text-transform:capitalize;
	font-family:'Raleway',Arial, Helvetica, sans-serif

} */

/* 
#my-account-admin-menu_buyer li a:hover
{
	background:#B55617;
	color:#fff;
	text-decoration:none

} */



#home-coin-slider
{
	margin:auto;
	border:5px solid #2A95EA;
	width:950px;
	background:white;
	-moz-border-radius: 10px;
	border-radius: 10px;



}


	#slider ul, #slider li{
		margin:0;
		padding:0;
		list-style:none;
		}
	#slider li{
		/*
			define width and height of list item (slide)
			entire slider area will adjust according to the parameters provided here
		*/


		overflow:hidden;
		}
	span#prevBtn{}
	span#nextBtn{}


.slider-title
{
	font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
	font-weight:bold
}

.slider-post
{
	width:193px;
	float:left;
	overflow:hidden;
	text-align:center !important;

}
.slider-post h2{
	font-size:13px;
	color:#333;
}

.slider-post p{
	text-align:center !important;
	color:#333;
}

.slider-post a:link, .slider-post a:visited
{
	color:#333
}

.slider-post a:hover
{
	color:#333
}

#slider-controls
{
	width:100%;
	border-top:1px solid #ccc;
	overflow:hidden
}

/* 

a.slider-controls:link, a.slider-controls:visited {
	background:#e9be2a ;
	display: inline-block;
	padding: 3px 12px 3px 12px;
	color: #333;
	text-decoration: none;
	-moz-border-radius: 5px;
	border-radius: 5px;
	-webkit-border-radius: 5px;

	position: relative;

	margin-left:3px;
	font-size:11px;
	font-family:Arial, Helvetica, sans-serif
}



a.slider-controls:hover
{

		background:#2272CA;
		color:#FFF;
		text-decoration:none;
} */

------------------------

/* .browse-by-location
{
	overflow:hidden
}



/*------------------------*/

.browse-by-category
{
	overflow:hidden
}



/*------------------------*/

/* .latest-posted-ads-big
{
	overflow:hidden
} */
/* 
.latest-posted-ads-big h3
{

    border-bottom: 1px dotted #999999;
    color: #666666;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 16px;
    font-weight: bold;
    padding-bottom: 5px;
    width: 100%;
    margin-bottom:2px
} */

/*------------------------*/

/* #location-stuff
{
	list-style-type: square;
	overflow:hidden;
	float:left;
	width:100%;
	padding:0;
	margin:0
}  */

/* #location-stuff li
{
	display:block; width:100%;
	overflow:hidden; border:0px
}

#location-stuff li h3
{
	font-size:14px;
	border:0px;
	padding:0px;
	margin:0px;
	margin-left:3px
}

#location-stuff li img
{
	float:left;
	margin-right:7px
}

#location-stuff li ul
{
	float:left;width:100%;
	overflow:hidden; padding:0; margin:0;
	list-style-type: square;
} */

/* #location-stuff li ul li
{

	width:100%;
	display:block;
	padding:0px;
	margin:0px;
	margin-left:8px;
	margin-bottom:7px;
	font-size:13px;

	border-bottom:1px dotted #ccc;
	padding-left: 10px;
padding-bottom: 5px;
background: url('images/bul.png') no-repeat;

}

#location-stuff li ul li.top-mark
{

	width:100%;
	display:block;
	padding:0px;
	margin:0px;
	margin-left:8px;
	margin-bottom:7px;
	font-size:13px;

	border-bottom: 1px dotted #DEDEDE;
	padding-left: 10px; padding-bottom:5px;
	background: url('images/bullet-cat.png') no-repeat
} */
.see-more-tax
{
	width:100%;
	float:left;

}


/*-----------*/
.breadcrumbs
{
	padding:10px;

}

.blog-image
{
	margin-right:10px;
	margin-bottom:5px;
	border:1px solid #ccc;
	padding:2px
}

#left-sidebar { width:280px; margin-top:10px; }
/* 
#right-sidebar .widget-container, #content .widget-container, #left-sidebar .widget-container
{
	/*box-shadow: 0 0 3px #ddd;
	-moz-box-shadow:0 0 3px #ddd;
	-webkit-box-shadow:0 0 3px #ddd;
	*/
} */
.widget-container
{
	text-align:left
}

#slider2 .nk_slider_child
{
	width:197px;
}


#auction-home-page-main-inner
{

	/*background:url(images/bkmain.jpg) repeat-x #6CA0DB;*/
	background:#fff;
	border:1px solid #ccc;
	display:none;

	margin-bottom:10px;
	margin-top:4px;
	border-radius:5px;
	box-shadow:0 0 6px #cecece;
	position:relative;
	 margin:auto;
	margin-bottom:13px;

}

.padd20
{
	padding:20px;
}

.bid_panel
{
	background:#e8e8e8;
	overflow:hidden	;
	width:100%;
	border-bottom:1px solid #ccc;
}

.bid_panel_err
{
	background:#EA554F;
	overflow:hidden	;
	width:400px; color:#fff;
	border-bottom:1px solid #ccc;
}

/* .bid_panel_ok
{
	background:#9C0;
	overflow:hidden	;
	width:100%; color:#333;
	border-bottom:1px solid #ccc;
} */
/* 
.my-buttons
{
	border: 0;
	padding: 12px 15px;
	font-size: 12px;
	color: #fff;
	border-radius: 4px;
	-webkit-border-radius: 4px;
	background: #B3CE51;
	border-bottom: 4px solid #7A9029;
	text-transform: uppercase;
	text-decoration: none;
	font-family: 'Raleway',Arial, Helvetica, sans-serif;
}




.my-buttons2
{
	padding:5px;
	border:1px solid #333333;
	background:#99CC00;
	color:#000;
	padding-top:2px;
	padding-bottom:2px;
}
 */



#result {
	height:20px;
	font-size:16px;
	font-family:Arial, Helvetica, sans-serif;
	color:#333;
	padding:5px;
	margin-bottom:10px;
	background-color:#FFFF99;
}
#country{
	padding:3px;
	border:1px #CCC solid;
	font-size:17px;
}
.suggestionsBox {
	position: absolute;
	left: 0px;
	/*top:40px;*/
	margin: 12px 0px 0px 0px;
	width: 400px;
	padding:0px;
	background-color: #333;
	border-top: 3px solid #333;
	color: #fff;
	border-radius:5px;
	-moz-border-radius:5px;
	-webkit-border-radius:5px;
}

.suggestionList ul li h2 {  width:55px; padding:0; margin:0; float:left; }
.suggestionList ul li p {  width:330px; padding:0; margin:0; float:left;}

.suggestionList {
	margin: 0px;
	padding: 0px;
}
.suggestionList ul li {
	list-style:none;
	margin: 0px;
	padding: 6px;
	border-bottom:1px dotted #333;
	cursor: pointer; overflow:hidden;
	text-align:left;
}
.suggestionList ul li:hover {
	background-color: #F2673A;
	color:#fff;
}

.load{
	background:white;
background-image:url(images/loader.gif);
background-position:right;
background-repeat:no-repeat;
}

#suggest {

    position: absolute;
    top: 5px;
	left:0;
	z-index:999;
}

#slider{ display:none }
a.green_btn:link, a.green_btn:visited {


	border-width: medium medium 2px;
	border-style: none none solid;
	border-color: -moz-use-text-color -moz-use-text-color #526615;
	-moz-border-top-colors: none;
	-moz-border-right-colors: none;
	-moz-border-bottom-colors: none;
	-moz-border-left-colors: none;
	border-image: none;
	padding: 3px;
	font-size: 11px;
	color: #FFF;
	background: #8CAA33;
	text-decoration: none;
	font-family: "Open Sans",Arial,Helvetica,sans-serif;
	margin-left: 2px;


}

.bold_stuff { font-weight:bold }


a.green_btn:hover
{

		background:#9C0;
		color:#FFF;
		text-decoration:none;
}

.error , .newauction_error
{
	border:1px solid #BE4C5A;
	background:#FCDCEC;
	color:red;
	padding:12px; border-radius:5px;
	margin-top:15px
}

.error { margin-bottom:15px }

.saved_thing
{
	border:1px solid #699443;
	background:#E8EFE4;
	color:#333;
	border-radius:4px;
	padding:12px;
	margin-top:15px;
	margin-bottom:10px
}

.paid_ok_thing
{
	border:1px solid #699443;
	background:#E8EFE4;
	color:#333;
	border-radius:4px;
	padding:12px;


}


.error ul { list-style:none; padding:0; margin:0 }

.errrs
{
	-moz-border-radius: 7px;
border-radius: 7px;
margin-bottom:10px;
		padding:15px;
		color:red;
		border:1px solid red;
}

.errrs3
{
	-moz-border-radius: 7px;
border-radius: 7px;
margin-bottom:10px;
		padding:15px;
		color:red; background:white;
		border:1px solid red;
}

.error2
{
	border:1px solid red;
	padding:5px; color:red;
	 float:left
}


.newproject_error
{
	border:1px solid #BE4C5A;
	background:#FCDCEC;
	color:red;
	padding:12px;
	margin-bottom:10px
}


.tripp { margin-top:10px; float:left; min-height:23px; }

#footer .textwidget
{ color:white; text-align:left; font-size:13px; }

.stuffa
{
	float:left;width:25%;
	overflow:hidden
}


.stuffa1
{
	float:left;width:100%;
	overflow:hidden
}

.stuffa2
{
	float:left;width:50%;
	overflow:hidden
}

.stuffa3
{
	float:left;width:33%;
	overflow:hidden
}

.stuffa4
{
	float:left;width:25%;
	overflow:hidden
}


.stuffa5
{
	float:left;width:20%;
	overflow:hidden
}


a.active-search-link:link, a.active-search-link:visited
{
	padding:2px; color:white; background:#6394C9; text-decoration:none
}


a.active-search-link:hover { background:#9ABECF }

.sealed-two
{
	background:url('images/sealed.html');
	width:56px;
	height:58px; top:1px; left:1px;
	position:absolute
}


.sealed-three
{
	background:url('images/sealed.html');
	width:56px;
	height:58px;top :0px; left:38px;
	position:absolute
}

.featured-three
{
	background:url('images/featured.png');
	width:97px;
	height:22px;
	top :0px; left:38px;
	position:absolute
}



.sealed-one
{
	background:url('images/sealed.html');
	width:56px;
	height:58px; top :0px;
	position:absolute
}

.featured-one
{
	background:url('images/featured.png');
	width:97px;
	height:22px; top :9px; left:-16px;
	position:absolute
}



.featured-one-m
{
	background:url('images/featured_small_m.png');
	width:85px;
	height:22px; top :9px; left: -5px;
	position:absolute
}

.featured-one_a
{
	background:url('images/featured1.png');
	width:60px;
	height:13px;
	top :3px; left:-4px;
	position:absolute
}

.featured-two
{
	background:url('images/featured.png');
	width:56px;
	height:58px;
	position:absolute
}

.main_description
{
	margin:auto;
	width:100%;
	font-size:14px;
	font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
	line-height:21px;

}




/*---------- login form --------------------*/

.login-submit-form p
{
	overflow:hidden
}
.login-submit-form p label
{
	min-width:120px;
	float:left;
	padding:5px;
	font-size:14px;
	font-weight:bold;
}

.check-email-div
{
	background:#FCFAE4;
	border:1px solid #F2C437;
	color:#333;
}

.fbc_loginstate_top { display:none }
.fb_login_head
{
	width:100%;
	text-align:right;
	height:50px
}

.fbc_connect_button_area { float:right }

.submit_bottom
{
	border:none;
	padding: 12px 15px;
	font-size: 15px;
	color: #fff;
	border-radius: 4px;
	-webkit-border-radius: 4px;
	background: #FFB300;
	border-bottom: 4px solid #D5800D;
	text-transform: uppercase;
	text-decoration: none;
	font-weight:600;
	font-family: 'Raleway',Arial, Helvetica, sans-serif;


}

.submit_bottom:hover { opacity:0.8 }

/*------------------------*/

.submit_bottom2
{
	border:none;
	padding: 3px 5px;
	font-size: 13px;
	color: #fff;
	border-radius: 4px;
	-webkit-border-radius: 4px;
	background: #FFB300;
	border-bottom: 2px solid #D5800D;
	text-transform: capitalize;
	text-decoration: none;
	font-weight:600;
	font-family: 'Raleway',Arial, Helvetica, sans-serif;


}

.submit_bottom2:hover { opacity:0.8 }

/*-----------------------*/

.special_breadcrumb {

	font-size:12px;
	color:#333;
	border:1px solid #54A1E9;
	background:#eee;
	width:100%;
	border-radius: 5%;


}

.cate_tax-bold { font-weight:bold }
.post-new-choose-tax { float:left; width:25%;font-size:14px; margin-bottom:15px; text-align:left }

a.goback-link:link, a.goback-link:visited { background:#4483B7; color:white; border:1px solid #ccc; padding:6px; border-radius:5px; margin-right:15px; }
a.pay_now:link, a.pay_now:visited { background:#4483B7; color:white; border:1px solid #ccc; padding:6px; border-radius:5px; margin-right:15px; }

.go-back-post-new { float:left;width:100%; margin-top:10px;margin-bottom:10px }

.stretch-area {
	text-align:left;
	overflow:hidden;
	position:relative;
	margin:auto;
	border:1px solid #dedede;

	-moz-border-radius: 0px 0px 10px 10px;
	-webkit-border-radius: 0px 0px 10px 10px;
	border-radius: 5px;

	box-shadow: 0 0 3px #ddd;
	-moz-box-shadow:0 0 3px #ddd;
	-webkit-box-shadow:0 0 3px #ddd;


	width:99.8%;
	background:#f4f4f4;
	margin-bottom:5px;
	margin-top:5px;


 }


 .2ndmenu {
 margin:auto;
 width:960px; }

 .watch-list{
	padding-top:8px;
	margin-left:-4px;
	text-align:center
 }

 .watch-list a.add-to-watchlist:link, .watch-list a.add-to-watchlist:visited
 {
	 padding:4px;
	 background:#5AA644;
	 color:#fff;
	 font-size:12px;
	 border-radius:4px;
	 -moz-border-radius:4px;
	 -webkit-border-radius:4px;


 }
 .watch-list a.add-to-watchlist:hover { text-decoration:none; background:#96BA43 }

 .watch-list a.rem-to-watchlist:link, .watch-list a.rem-to-watchlist:visited
 {
	 padding:4px;
	 background:#B5412D;
	 color:#fff;
	 font-size:12px;
	 border-radius:4px;
	 -moz-border-radius:4px;
	 -webkit-border-radius:4px;


 }


  .watch-list a.rem-to-watchlist:hover { text-decoration:none; background:#DC6D61 }

  /*--------------------------------*/

  .watch-list a.add-to-watchlist2:link, .watch-list a.add-to-watchlist2:visited
 {
	 padding:4px;
	 background:#5AA644;
	 color:#fff;
	 font-size:10px;
	 border-radius:4px;
	 -moz-border-radius:4px;
	 -webkit-border-radius:4px;


 }
 .watch-list a.add-to-watchlist2:hover { text-decoration:none; background:#96BA43 }

 .watch-list a.rem-to-watchlist2:link, .watch-list a.rem-to-watchlist2:visited
 {
	 padding:4px;
	 background:#B5412D;
	 color:#fff;
	 font-size:10px;
	 border-radius:4px;
	 -moz-border-radius:4px;
	 -webkit-border-radius:4px;


 }


  .watch-list a.rem-to-watchlist2:hover { text-decoration:none; background:#DC6D61 }


  /**************************************************/

  a.place_task:link,  a.place_task:visited, a.place_service:link,  a.place_service:visited
  {
		padding: 12px 15px;
font-size: 15px;
color: #fff;
border-radius: 4px;
-webkit-border-radius: 4px;
background: #FFB300;
border-bottom: 4px solid #D5800D;
text-transform: uppercase;
text-decoration: none;
font-family: 'Raleway',Arial, Helvetica, sans-serif;

  }

   a.place_task:hover,  a.place_service:hover
  {
	opacity:0.8;
	text-decoration:none
  }

  .task_service_button{



		margin:15px 0 15px 0;
		text-align:center;


  }

  .text_service
  {
		padding-bottom:40px;
		padding-left:60px;
		padding-right:60px  ;
		font-family: "Aller_Bd",Tahoma, Geneva, sans-serif;
		font-size:14px;
		color:#777
  }

  /*-------------------*/

  .task_badge
  {
		position:absolute;
		font-size:11px;
		background:#8CAA33;
		color:white;
		border-radius:3px;
		padding:3px; padding-top:1px; padding-bottom:1px;
		text-transform:uppercase;
		right:15px
  }

    .service_badge
  {
		position:absolute;
		font-size:11px;
		background:#E1A30F;
		color:white;
		border-radius:3px;
		padding:3px; padding-top:1px; padding-bottom:1px;
		text-transform:uppercase;
		right:15px
  }


  /*------------------*/

  a.buttonlight {
 margin-top:10px;
 height: 30px;
 line-height: 30px;
 font-size: 12px;
 -webkit-border-radius: 5px;
 -moz-border-radius: 5px;
 border-radius: 5px;
 box-shadow:0 0 5px #ccc;

}

.slider-post a.buttonlight:link, a.buttonlight:visited {

 color:#fff;
 padding: 5px 20px 5px 20px;
 text-align: center;
 text-shadow: 0px 0px 3px #333;
background: #84b233; /* Old browsers */
background: -moz-linear-gradient(top, #84b233 49%, #639b01 52%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(49%,#84b233), color-stop(52%,#639b01)); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top, #84b233 49%,#639b01 52%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top, #84b233 49%,#639b01 52%); /* Opera 11.10+ */
background: -ms-linear-gradient(top, #84b233 49%,#639b01 52%); /* IE10+ */
background: linear-gradient(to bottom, #84b233 49%,#639b01 52%); /* W3C */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#84b233', endColorstr='#639b01',GradientType=0 ); /* IE6-9 */
 border: 1px solid #fff;
 text-decoration: none;
 font-weight: bold;
 box-shadow:0 0 5px #999;
}

.slider-post a.buttonlight:hover  {
 color: #fff;
 text-shadow: 1px 1px 0px #000;
 background: #333;
 border: 1px solid #555555;
 text-decoration: none;
}

.sclk { border:0 }

.widget-container ul { padding:0; margin:0; list-style-type:none }
.widget-container ul li { margin-bottom:6px; }


.main_wrapper { width:95%; display:inline-block; text-align:center }
.main_wrapper_slider { width:95%; display:inline-block;  text-align:center }
.main_wrapper_menu { width:95%; display:inline-block;  text-align:center }

.content_super_div
{
	margin:auto;
	width:100%;
	text-align:center;
	display:inline-block
}

.main_wrapper {
        width: 1050px; /* 1140px - 10% for margins */
        margin: 0 auto;
    }

	#main { width:1050px;
    
    padding:20px;
     }
	.main_wrapper_slider { width:985px }
	.main_wrapper_menu { width:985px }

/*----------*/

.sidebar-for-account
{
	float:left !important
}

.content-for-account
{
	float:right !important
}

.avatar_ma
{
	padding:3px;
	border:1px solid #dedede;
	border-radius:50%;
}

.main_avatar
{
	width: 100%;
    text-align: center;
   
    padding-top: 20px;
    padding-bottom: 30px;
    margin-bottom: 20px;
    border-radius: 5%;
    box-shadow: 1px 1px green;
    background: rgb(204, 252, 230);
}

.name_account_main
{
	font-weight:bold;
	font-size:14px;
}

/*-----------------*/


@media  only screen and (min-width: 950px) {
	.top-links
	{
		margin-top:22px !important;
	}
}

@media  only screen and (max-width: 900px) {
	#header .middle-header
	{
		margin-left:auto;
		margin-right:auto;

		margin-bottom:5px;
		float:none;
	}
}

@media  only screen and (max-width: 1024px) {
	#main, #colophon
	{
		width:100%
	}

	.main-thing-menu { width:100%; }

	.main-thing-menu-wrap
	{
		min-height:90px
	}



	.logo-holder
	{
		margin-bottom:20px;
	}

	.post_new_link_div
	{
		margin-right:15px;
	}

}

@media  only screen and (width: 480px) {

	#header .middle-header { width:460px }
	#big-search { width:410px }

}

@media  only screen and (max-width: 480px) {
.widget-title span, .box_title span { font-size:11px; }
}

@media  only screen and (min-width: 1024px) {

/* ===============
    Maximal Width
   =============== */

    .main_wrapper {
        width: 1050px; /* 1140px - 10% for margins */
        margin: 0 auto;
    }

	
    #main {
    width: 100%;
    margin: 5% 0;
    padding:10px;
    }
	.main_wrapper_slider { width:985px }
	.main_wrapper_menu { width:985px }



}


@media  only screen and (max-width: 1024px) {
	#map { width:92% !important }
}



@media  only screen and (max-width: 800px) {

	.stuffa2,.stuffa3,.stuffa4,.stuffa5 { width:50% }

	.main_wrapper { width:100%; display:inline-block; text-align:center }
	.main_wrapper_slider { width:95%; display:inline-block;  text-align:center }
	.main_wrapper_menu { width:95%; display:inline-block;  text-align:center }
	.home_blur { height:650px }


	#steps ul li { margin-right:5px; }
	#steps ul { margin-left:10px; margin-right:0 ; padding: 0 }
	#steps ul li { padding:11px 10px 10px 10px; }

}

@media  only screen and (max-width: 500px) {

	#site-info-left { width:100%; margin:auto; text-align:center; margin-bottom:5px }
	#site-info-right { width:100%; margin:auto; text-align:center; margin-bottom:5px }

	.stuffa, #location-stuff li ul
	{
		width:100% !important
	}
	
	.multi_cat_placeholder_thing { width:90% }

	.widget-title span, .box_title span { left:5px; }
	.home_blur { height:590px }
	#steps ul li { margin-right:5px; }
	#steps ul { margin-left:0; margin-right:0 ; padding: 0 }
	#steps ul li { padding:11px 5px 10px 5px; }
	.stuffa2,.stuffa3,.stuffa4,.stuffa5 { width:100% }

	.main_wrapper { width:100%; display:inline-block; text-align:center }
	.main_wrapper_slider { width:95%; display:inline-block;  text-align:center }
	.main_wrapper_menu { width:95%; display:inline-block;  text-align:center }

	#header #logo { padding-left:10px }

	.main_tagLine { font-size:20px }
	.sub_tagLine { font-size:14px; padding-left:10px; padding-right:10px }
	.regular_ul li a:link, .regular_ul li a:visited
	{
		font-size:12px;
	}

}
</style>