<?php $__env->startSection('content'); ?>
<section class="inner-header-title" style="background-image:url(assets/img/banner-10.jpg);">
    <div class="container">
        <h1>DELIVERY</h1>
    </div>
</section>
<section class="accordion">
    <div class="container">
        <div class="col-md-12 col-sm-12">
            <form action="<?php echo e(url('project_delivery/'.$proposal)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
                <textarea class="form-control" >Descripton about the delivery</textarea>
                <label>Attachment</label>
                <input type="file" name="file" class="form-control">
                <input type="submit" class="btn btn-success">
            </form>
           
       
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_html.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>