
<div class="alert alert-info">
    <b>Total <?php echo e($pros->total()); ?> Pro Found.</b>
</div>
<?php $__currentLoopData = $pros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
  //  print_r($freelancers);
  $people=App\Pro::where('user_id',$pro->id)->first();
  $country=null;
  if($people->address!=null){
     $country=$people->address;
    $country_code=explode($country,',');
    $country=App\Country::find($country_code[0]);
    // print_r($country);
  }
 
?>
<div class="col-md-4 col-sm-6">
    <div class="freelance-container style-2">
        <div class="freelance-box">
             <span class="freelance-status"><?php echo e(checkAvailablity($pro->is_available)); ?></span> 
            <span class="freelance-status-right">Level:<?php echo e($people->level); ?></span> 
            <div class="freelance-inner-box">
                <div class="freelance-box-thumb">
                    <img src="<?php echo e(asset('_html/assets/img/can-5.jpg')); ?>" class="img-responsive img-circle" alt="" />
                </div>
                <div class="freelance-box-detail">
                     <h4><?php echo e($pro->name); ?></h4>
                     
                    <?php if($country): ?>
                        <span class="location"><?php echo e($country->name); ?></span>
                    <?php endif; ?> 
                    <?php if($people): ?>
                        <h6><?php echo e($people->short_description); ?></h6>
                    <?php endif; ?>
                </div>
                <?php if($pro->rating): ?>
                <div class="rattings">
                    <?php for($i = 0; $i
                    < $pro->rating; $i++): ?>
                        <i class="fa fa-star fill"></i> <?php endfor; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="freelance-box-extra">
                <?php
                    $skills=App\SkillDetails::where('user_id',$pro->id)->get();
                ?>
                <?php if($skills): ?>
                <ul>
                    <?php for($i = 0; $i< count($skills); $i++): ?> 
                        <?php if($i < 3): ?>
                        <?php
                            $s=App\Skill::find($skills[$i]->skill_id);
                        ?>
                            <?php if($s): ?>
                                 <li><?php echo e($s->name); ?></li>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endfor; ?>
                        <?php if(count($skills) > 3): ?>
                          <li class="more-skill bg-primary">+<?php echo e(count($skills) - 3); ?></li>
                        <?php endif; ?>
                </ul>
                <?php endif; ?>
            </div>
            <a href="<?php echo e(url('Worker_Details/'. urlencode(base64_encode($pro->id)))); ?>" class="btn btn-freelance-two bg-default">View Detail</a>
        </div>
    </div>
</div>  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
    <?php echo $pros->links(); ?>

</div>