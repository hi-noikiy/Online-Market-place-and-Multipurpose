<?php $__env->startSection('title','My active Service'); ?>
<?php $__env->startSection('chore_content'); ?>
<div class="breadcrumb-wrap">
    <div class="padd10">
        <span typeof="v:Breadcrumb">
        <a  href="<?php echo e(url('/')); ?>" class="main-home">Healthbuite</a></span> &gt; 
        <span typeof="v:Breadcrumb"><a  href="<?php echo e(url('chores/admin')); ?>" class="home">My Account</a></span>
    </div>
</div>
<?php
$id = Auth::user()->id;

$chore = App\chore::where('creator', $id)->where('type',2)->get();
?>
<div id="content" class="content-for-account  col-xs-10 col-sm-8 col-lg-8 ">
     <div class="my_box3" style="height:100%">      
         
        <h6 class="widget-title">
                <span> 
                    I have Sold
                </span>
        </h6>

      <div>
          <?php if($chore): ?>
            <?php $__currentLoopData = $chore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $proposal=App\Chore_proposal::where('chore_id',$chore->id)->where('status',1)->first();
                    // print_r($chore->id);
                    // exit();
                    // if($proposal){
                    //     if($proposal->status==1){
                    //         continue;
                    //     }
                    // }
                    if(!$proposal){
                        continue;
                    }
                    
                ?>
                <div class="proposal">
                    <div style="width:100%">
                        <h6 class=""><strong>Task Is: </strong><?php echo e($chore->name); ?></h6>
                        <?php
                            $sender=App\All_user::find($proposal->user_id);
                          // print_r($sender);
                        ?>
                        <h6 class=""><strong>Sold To: </strong><?php echo e($sender->name); ?></h6>
                        <h6 class=""><strong> Email:</strong> <?php echo e($sender->email); ?></h6>
                        <h6>Accepted at: <?php echo e($proposal->updated_at); ?></h6>
                    </div>
                   
                    <div style="width:100%">
                        
                        <div class="">
                             <br>
                            
                           <strong>Price : $</strong><?php echo e($proposal->price); ?>

                        </div>
                       
                    </div>
                    
                    

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>

      </div>
        
     </div>

<?php
$id = Auth::user()->id;

$proposal =App\Chore_proposal::where('user_id', $id)->where('status',1)->get();
?>

     <div class="my_box3" style="height:100%">      
         
        <h6 class="widget-title">
                <span> 
                    I have bought
                </span>
        </h6>

      <div>
          <?php if($proposal): ?>
            <?php $__currentLoopData = $proposal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $chore=App\chore::where('id',$proposal->chore_id)->first();
                    // print_r($chore->id);
                    // exit();
                    // if($proposal){
                    //     if($proposal->status==1){
                    //         continue;
                    //     }
                    // }
                    if(!$chore){
                        continue;
                    }
                    
                ?>
                <div class="proposal">
                    <div style="width:100%">
                        <h6 class=""><strong>Task Is: </strong><?php echo e($chore->name); ?></h6>
                        <?php
                            $sender=App\All_user::find($chore->creator);
                          // print_r($sender);
                        ?>
                        <h6 class=""><strong>Job of : </strong><?php echo e($sender->name); ?></h6>
                        <h6 class=""><strong> Email:</strong> <?php echo e($sender->email); ?></h6>
                        <h6>Accepted at: <?php echo e($proposal->updated_at); ?></h6>
                    </div>
                   
                    <div style="width:100%">
                        
                        <div class="">
                             <br>
                            
                           <strong>Price : $</strong><?php echo e($proposal->price); ?>

                        </div>
                       
                    </div>
                    
                    

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>

      </div>
        
     </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('chore.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>