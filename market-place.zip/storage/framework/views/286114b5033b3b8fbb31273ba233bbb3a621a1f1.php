
<div class="alert alert-info">
    <b>Total <?php echo e($response['projects']->total()); ?> Projects Found.</b>
</div>
<style>
.des{
    overflow: hidden;
    height: 25px;
}
.des:hover{
    height: 100%;
    overflow-y: scroll;
    background: greenyellow;
    color: black;
}
</style>

<?php $__currentLoopData = $response['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $image=App\Image::where('type',7)->where('item_id',$project->id)->first();
    $type=['Permanant','Part time','Intern','Temporary'];
    $user=$project->customer;
    $user=App\Customer::find($user);
    $user=App\User::find($user->user_id);
?>
<div class="item-click">
    <article>
        <div class="brows-job-list">
            <div class="col-md-1 col-sm-2 small-padding">
                <div class="brows-job-company-img">
                    <?php if($image): ?>
                    <a href="job-detail.html"><img src="<?php echo e(asset('uploads/file/'.$image->image)); ?>" class="img-responsive" alt="" /></a>
                    <?php else: ?> 
                    <a href="job-detail.html"><img src="http://www.illuminationworksllc.com/wp-content/uploads/2017/04/ProjectManagement-1.jpg" class="img-responsive" alt="" /></a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6 col-sm-5">
                <div class="brows-job-position">
                    <a href="job-apply-detail.html"><h3><?php echo e($project->title); ?></h3></a>
                    <p>
                        <span><?php echo e($user->name); ?></span><span class="brows-job-sallery"><i class="fa fa-money"></i>
                            <?php if($project->min): ?>
                            $<?php echo e($project->min); ?>

                            <?php endif; ?>
                             - 
                             <?php if($project->max): ?>
                             $<?php echo e($project->max); ?>

                             <?php endif; ?>
                            </span>
                          
                   <i class="fa ">
                    <?php if($project->duration): ?>    
                    </i>Duration: <?php echo e($project->duration); ?> Days
                    <?php endif; ?>
             
                        
                    </p>

                    <p>
                        <?php
                            $skill=App\SkillDetails::where('item_type',0)->where('item_id',$project->id)->get();
                        ?>
                        <span>Requirements</span>
                        <span class="brows-job-sallery">
                            <?php if($skill): ?>
                                <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $s=App\Skill::find($skill->skill_id);
                                    ?>
                                    <?php if($s): ?>
                                      <span class="w3-tag w3-small" id="spans" style="background-color: #7ed85b; border-radius: 20px;"><?php echo e($s->name); ?></span>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </span>
                        <div class="col-md-8 col-sm-8 des">
                           <p> <?php echo e($project->description); ?></p>
                        </div>
                        
                        
                    </p>
                </div>
            </div>
            <div class="col-md-3 col-sm-3">
                <div class="brows-job-location">
                    <p><i class="fa ">
                    <?php if($project->Location): ?>    
                    </i><?php echo e($project->Location); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="col-md-2 col-sm-2">
                <div class="brows-job-link">
                    <?php
                        $u=Auth::guard('admin')->user();
                        $freelancer_proposal=App\FreelancerProjectProposal::where('project_id',$project->id)->where('user_id',$u->id)->first();
                        $status=['Not Accepted Yet','Accepted','Denied'];
                    ?>
                    <?php if($freelancer_proposal): ?>
                     <a  class="btn btn-default" ><?php echo e($status[$freelancer_proposal->status]); ?></a>
                    <?php else: ?> 
                     <a  class="btn btn-default" data-toggle="modal" data-target="#exampleModalCenter">Apply Now</a>
                    <?php endif; ?>
                   
                </div>
            </div>
        </div>
        <?php if($project->type): ?>
        <span class="tg-themetag tg-featuretag"><?php echo e($type[$project->type]); ?></span>
        <?php endif; ?>
    </article>
</div>


<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade container" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Send Proposal</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(url('post_a_proposal')); ?>" method="POST" class="card">
            <?php echo csrf_field(); ?>

            <input type="hidden" value="<?php echo e($project->id); ?>" name="project_id">
            <div class=form-control">
            <label for="">Description</label>
            <textarea rows="5"  class="form-control" name="description">
                Describe Your Proposal
            </textarea>
            </div>
            <div class=form-control">
            <label for="">Delivery in</label>
            <input type="number" class="form-control" name="delivery">
            </div>
            <div class=form-control">
            <label for="">Price</label>
            <input type="number" class="form-control" name="price">
            </div>
            <div class=form-control">
                <label for="">Send option with the gig</label>
                <select name="" id="" class="form-control" name="gig_id">
                    <?php
                        $u=Auth::guard('admin')->user();
                        $f=App\Freelancer::where('user_id',$u->id)->first();
                        $g=App\Gig::where('freelancer_id',$f->id)->get();
                    ?>
                    <?php if($g): ?>
                        <?php $__currentLoopData = $g; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($gig->id); ?>"><?php echo e($gig->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  
            
                </select>
            </div>
            <input type="submit" class="btn btn-success" value="Send">
        </form>
      </div>
     
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php echo $response['projects']->links(); ?>