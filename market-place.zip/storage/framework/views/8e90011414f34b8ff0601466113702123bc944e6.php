<?php
    $user=App\User::find($id);
    // print_r($user);
    // exit();
?>


<?php $__env->startSection('dascontent'); ?>

<div class="w3-container"><br>
  <style>
  .review-detail {
    display: table;
    margin-left: 100px;
    background: white;
    padding: 5px;
}
  </style> 
   
    <div class="">

        <!-- Single Review -->
         <?php
               $review= \App\Helpers\GeneralHelper::get_total_review($user->id,3);
            // if($user->user_type==3){
          
            // }elseif($user->user_type==4) {
            //     $review= \App\Helpers\GeneralHelper::get_total_review($user->id,4);
            // }
        // print_r($review);
        // exit();    
        
    ?>
        <div class="">
            <div class="review-thumb">
                <img src="http://via.placeholder.com/180x180" class="img-responsive img-circle" alt="" />
            </div>
            <div class="review-detail">
                <?php if($review): ?>
                    <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    if($review->giver_type==0){
                    $giver=App\All_user::find($review->giver_id);
                    }elseif ($review->giver_type==1) {
                        $giver=App\User::find($review->giver_id);
                    }  
                    ?>
                    <h4><?php echo e($giver->name); ?><span>at <?php echo e($review->created_at); ?></span></h4>
                
                    
                    <p><?php echo e($review->comment); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>    
            </div>
        </div>

    </div>

      <hr>
  </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_html.freelancer.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>