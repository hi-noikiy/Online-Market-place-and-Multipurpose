<?php $__env->startSection('dascontent'); ?>
<?php
    $user=App\User::find($id);
    $freelancer=App\Freelancer::where('user_id',$user->id)->first();
?>
<div>
    <div class="col-md-4 col-sm-4">
        <div class="card">
            <div class="card-body">
              
                <?php
                    $completed_order=App\ProFreeOrder::where('freelancer_type',0)->where('freelancer_id',$freelancer->id)->where('status',1)->get();
                ?>
                  <h5 class="card-title">Completed Orders <span class="badge badge-secondary"><?php echo e(count($completed_order)); ?></span></h5>
                <?php if($completed_order): ?>
                    <?php $__currentLoopData = $completed_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                       // $project=App\
                    ?>
                        <p class="card-text">Owner Name:</p>
                        <p class="card-text">Project title:</p>
                        <p class="card-text">Competation date: <?php echo e($order->created_at); ?></p>
                        <p class="card-text">Price: $<?php echo e($order->price); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                <?php endif; ?>
                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-4"> 
        <div class="card">
            <div class="card-body">
                
                <?php
                    $completed_order=App\ProFreeOrder::where('freelancer_type',0)->where('freelancer_id',$freelancer->id)->where('status',0)->get();
                ?>
                <h5 class="card-title">Not yet Completed Orders <span class="badge badge-secondary"><?php echo e(count($completed_order)); ?></span></h5>
                <?php if($completed_order): ?>
                    <?php $__currentLoopData = $completed_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                       // $project=App\
                    ?>
                        <p class="card-text">Owner Name:</p>
                        <p class="card-text">Project title:</p>
                        <p class="card-text">Competation date: <?php echo e($order->created_at); ?></p>
                        <p class="card-text">Price: $<?php echo e($order->price); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                <?php endif; ?>
                
            </div>
        </div>
    </div>
    
</div>
<br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_html.freelancer.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>