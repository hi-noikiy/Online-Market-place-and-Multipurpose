<?php $__env->startSection('title','Active Service'); ?>
<?php $__env->startSection('chore_content'); ?>
<div class="breadcrumb-wrap">
    <div class="padd10">
        <span typeof="v:Breadcrumb">
        <a  href="<?php echo e(url('chores/admin')); ?>" class="main-home">My account</a></span> &gt; 
        <span typeof="v:Breadcrumb"><a  href="<?php echo e(url('service/my_active_service')); ?>" class="home">Proposal Receivedt</a></span>
    </div>
</div>
<?php
$id = Auth::user()->id;

$chore = App\chore::where('creator', $id)->where('type',2)->get();
?>
<div id="content" class="content-for-account  col-xs-10 col-sm-8 col-lg-8 ">
     <div class="my_box3" style="height:100%">      
         
        <h6 class="widget-title">
                <span> 
                    Active Service
                </span>
        </h6>

      <div>
          <?php if($chore): ?>
            <?php $__currentLoopData = $chore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    // $proposal=App\Chore_proposal::where('chore_id',$chore->id)->first();
                    // // print_r($chore->id);
                    // // exit();
                    // if($proposal){
                    //     if($proposal->status!=0){
                    //         continue;
                    //     }
                    // }
                    // if(!$proposal){
                    //     continue;
                    // }
                    
                ?>
                <div class="proposal">
                    <div style="width:100%">
                        <h6 class=""><strong>Task Is: </strong><?php echo e($chore->name); ?></h6>
                        
                        <h6 class=""><strong>Sender Name: </strong>Me</h6>
                        <h6 class=""><strong>Sender Email:</strong> My email</h6>
                        <h6>created at: <?php echo e($chore->created_at); ?></h6>
                    </div>
                   
                    <div style="width:100%">
                        
                        <div class="">
                             <br>
                            
                           <strong>Price mentioned: $</strong><?php echo e($chore->price); ?>

                        </div>
                       
                    </div>
                    
                    

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>

      </div>
        
     </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('chore.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>