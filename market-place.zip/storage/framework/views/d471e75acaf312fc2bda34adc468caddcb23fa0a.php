 
<?php $__env->startSection('title', 'Freelancer Details'); ?> 
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<!-- Title Header Start -->
<section class="inner-header-page">
    <div class="container">
<?php
    if($user->user_type==3){
        $Freelancer=App\Freelancer::where('user_id',$user->id)->first();
    }
    if($user->user_type==4)
    {
        $Freelancer=App\Pro::where('user_id',$user->id)->first();
    }
  
    $country=null;
    if($Freelancer->address!=null){
         
         $country=$Freelancer->address;
        
        $country_code=$Freelancer->country_code;
          if($country_code){
             $country=App\Country::find($country_code);
          }
       
       
       
    }
   
?>
        <div class="col-md-8">
            <div class="left-side-container">
                <div class="freelance-image"><a href="company-detail.html">
                    <img src="<?php echo e(asset('uploads/user/'.$Freelancer->profile_image)); ?>" class="img-responsive img-circle" alt="https://galileo-camps.com/wp-content/themes/galileo-learning/library/img/default-person.png"></a>
                </div>
                <div class="header-details">
                    <h4><?php echo e($user->name); ?><span class="pull-right">$<?php echo e($Freelancer->hourly_rate); ?>/hr</span></h4>
                    <p><?php echo e($Freelancer->short_description); ?></p>
                    <ul>
                        
                        <li>
                           <div id="rateYo"></div>
                        </li>
                        <?php if($country!=null): ?>
                        <li><img class="flag" src="assets/img/gb.svg" alt=""> <?php echo e($country->name); ?></li>
                        <?php endif; ?>
                        <li>
                            <?php if($Freelancer->verified_at==1): ?>
                            <div class="verified-action">Verified</div>
                            <?php else: ?>
                            <div class="verified-action">Not Verified</div>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-4 bl-1 br-gary">
            <div class="right-side-detail">
                <ul>
                    <?php if($Freelancer->availability!=null): ?>
                    <?php
                        $availability=['Permanant','Part Time','Intern'];

                    ?>
                    <li><span class="detail-info">Availability</span><?php echo e($availability[$Freelancer->availability]); ?><span class="available-status">Available</span></li>
                    <?php else: ?> 
                    <li><span class="detail-info">Availability</span> Not Specified</li>
                    <?php endif; ?>
                    <?php if($Freelancer->address=!null): ?>
                    
                         <li><span class="detail-info">Location: <?php echo e($Freelancer->address); ?></span></li>
                    <?php else: ?>
                        <li><span class="detail-info">Location: Not Available</span></li> 
                    <?php endif; ?>
                   
                    <li><span class="detail-info">Joined at</span><?php echo e($user->created_at); ?></li>
                    <li><span class="detail-info">Age</span><?php echo e($Freelancer->age); ?></li>
                </ul>
                <ul class="social-info">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                   
                </ul>
            </div>
        </div>

    </div>
</section>
<div class="clearfix"></div>
<!-- Title Header End -->

<!-- Freelancer Detail Start -->

<section>
    <div class="container">

        <div class="col-md-8 col-sm-8">
            <div class="container-detail-box">

                <div class="apply-job-header">
                    <h4><?php echo e($user->name); ?></h4>
                    <a href="company-detail.html" class="cl-success"><span><i class="fa fa-building"></i><?php echo e($Freelancer->short_description); ?></span></a>
                    <span>
                        <?php if($country!=null): ?>
                        <i class="fa fa-map-marker"></i><?php echo e($country->name); ?>

                        <?php endif; ?>
                    </span>
                </div>

                <div class="apply-job-detail">
                    <p><?php echo e($Freelancer->long_description); ?></p>
                </div>

                <div class="apply-job-detail">
                    <h5>Skills</h5>
                    <?php
                    $skills=App\SkillDetails::where('user_id',$user->id)->get();
                    ?>
                    <ul class="skills">
                        <?php if($skills): ?>
                            <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $skill_name=App\Skill::find($skill->skill_id);
                            ?>
                               <?php if($skill_name): ?>
                                 <li><?php echo e($skill_name->name); ?></li>
                                <?php endif; ?> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>         

                       
                    </ul>
                </div>

                <div class="apply-job-detail">
                    <h5>Language</h5>
                    <ul class="language">
                        <?php
                            $language=App\LanguageDetails::where('user_id',$user->id)->get();
                        ?>
                        <?php if($language): ?>
                            <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $lan=App\Language::find($language->language_id);
                            ?>
                                <li><img class="flag" src="assets/img/gb.svg" alt=""><?php echo e($lan->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>    
                       
                    </ul>
                </div>

                

            </div>

            <!-- Similar Jobs -->
            <div class="container-detail-box">

                <div class="row">
                    <div class="col-md-12">
                        <h4>Review</h4>
                    </div>
                </div>

                <?php
                    $review= \App\Helpers\GeneralHelper::get_total_review($user->id,3);
                   
                ?>
                <div class="row">
                     <?php if($review): ?>
                        <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $sender=App\User::find($review->giver_id);
                            $customer=App\Customer::where('user_id',$sender->id)->first();
                            $im=App\Image::where('type',2)->where('item_id',$customer->id);
                        ?>
                    <!-- Single Review -->
                    <div class="review-list">
                        <div class="review-thumb">
                            <?php if($im): ?>
                           
                             <img src="<?php echo e(asset('uploads/user/'.$customer->profile_image)); ?>" class="img-responsive img-circle" alt="" />
                            <?php else: ?> 
                            <img src="https://galileo-camps.com/wp-content/themes/galileo-learning/library/img/default-person.png" class="img-responsive img-circle" alt="" />
                            <?php endif; ?>
                        </div>
                        <div class="review-detail">
                           
                             <?php
                                if($review->giver_type==0){
                                $giver=App\All_user::find($review->giver_id);
                                }elseif ($review->giver_type==1) {
                                    $giver=App\User::find($review->giver_id);
                                }  
                             ?>
                                <h4><?php echo e($giver->name); ?><span>at <?php echo e($review->created_at); ?></span></h4>
                            
                                
                                <p><?php echo e($review->comment); ?></p>
                             
                        </div>
                    </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>    

                </div>

            </div>
        </div>

        <!-- Sidebar Start-->
        <div class="col-md-3 col-sm-3">

            <!-- Make An Offer -->
            <div class="sidebar-container">
                <div class="sidebar-box">
                   <?php if($Freelancer->availability!=null): ?>
                    <?php
                        $availability=['Permanant','Part Time','Intern'];

                    ?>
                    <li><span class="detail-info">Availability</span><?php echo e($availability[$Freelancer->availability]); ?><span class="available-status">Available</span></li>
                    <?php else: ?> 
                    <li><span class="detail-info">Availability</span> Not Specified</li>
                    <?php endif; ?>
                    <h4 class="flc-rate"><?php echo e($Freelancer->hourly_rate); ?>/hr</h4>
                    <div class="sidebar-inner-box">
                        <div class="sidebar-box-thumb">
                            <img src="<?php echo e(asset('uploads/user/'.$Freelancer->profile_image)); ?>" class="img-responsive img-circle" alt="https://galileo-camps.com/wp-content/themes/galileo-learning/library/img/default-person.png" />
                        </div>
                        <div class="sidebar-box-detail">
                            <h4><?php echo e($user->name); ?></h4>
                            <span class="desination"><?php echo e($Freelancer->short_description); ?></span>
                        </div>
                    </div>
                    <div class="sidebar-box-extra">
                         <?php
                             $skills=App\SkillDetails::where('user_id',$user->id)->get();
                          ?>
                        <?php if($skills): ?>
                        <ul>
                            <?php for($i = 0; $i< count($skills); $i++): ?> 
                                <?php if($i < 3): ?>
                                <?php
                                    $s=App\Skill::find($skills[$i]->skill_id);
                                ?>
                                    <?php if($s): ?>
                                        <li><?php echo e($s->name); ?></li>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endfor; ?>
                                <?php if(count($skills) > 3): ?>
                                <li class="more-skill bg-primary">+<?php echo e(count($skills) - 3); ?></li>
                                <?php endif; ?>
                        </ul>
                        <?php endif; ?>
                        <ul class="status-detail">
                            <li class="br-1"><strong><?php echo e($Freelancer->response_time); ?></strong>Average Response Time</li>
                            <?php
                              $profreeorder=App\ProFreeOrder::where('freelancer_id',$user->id)->where('status',1)->count();  
                            ?>
                            <li class="br-1"><strong><?php echo e($profreeorder); ?></strong>Done job</li>
                            <li><strong>44</strong>Rehired</li>
                        </ul>
                    </div>
                </div>
                <?php if(Auth::guard('admin')->user()==$user): ?>
                  <a href="sidebarr-detail.html" class="btn btn-sidebar bt-1 bg-success">Contact</a>
                <?php else: ?> 
                  <a href="<?php echo e(url('make_an_offer')); ?>" class="btn btn-sidebar bt-1 bg-success">Contact</a>
                <?php endif; ?>
              
            </div>

            <!-- Website & Portfolio -->
            <div class="sidebar-wrapper">
                <div class="sidebar-box-header bb-1">
                    <h4>Website & Portfolio</h4>
                </div>

                <ul class="block-list">
                    <li><i class="fa fa-globe cl-success"></i>www.mysite.com</li>
                    <li><i class="fa fa-briefcase cl-success"></i>Portfolio</li>
                    <li><i class="fa fa-pencil cl-success"></i>My Blog</li>
                </ul>
            </div>

            <!-- Similar Profile -->
            <div class="sidebar-wrapper">

                <div class="sidebar-box-header bb-1">
                    <h4>Similar Profiles</h4>
                </div>

                <div class="member-profile-list">
                    <div class="member-profile-thumb">
                        <a href="company-detail.html"><img src="assets/img/can-2.png" class="img-responsive img-circle" alt="" /></a>
                    </div>
                    <div class="member-profile-detail">
                        <h4><a href="company-detail.html">Adam Crivatinly</a></h4>
                        <span>Web Developer</span>
                        <span class="cl-success">Freelancer</span>
                    </div>
                </div>

               

               

            </div>

            <!-- Share This Job -->
            

        </div>
        <!-- End Sidebar -->

    </div>
</section>
<!-- Freelancer Detail End -->
<script>
/* Javascript */

var ra;
window.onload=function(){
   ra=3;
   
     $.ajax({
        type:'get',
        url:'<?php echo e(url('/getstarvalue')); ?>',
        data:{'item_id':<?php echo e($user->id); ?>, 'item_type':<?php echo e($user->user_type); ?>},
        success:function(data){
           
            ra=data.number;
             console.log(ra);
        }
    })
 
$(function () {
 
  $("#rateYo").rateYo({
    rating: ra,
    readOnly: true
  });
});
}


</script>
<?php $__env->stopSection(); ?>
 <?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).on('click', '.pagination a', function(event) {
        event.preventDefault();
        var page = $(this).attr('href').split('page=')[1];
        paginageData(page);
    });

    function paginageData(page) {
        $.ajax({
            type: 'POST',
            url: baseUrl + "Customer/ReadFreelancer?page=" + page,
            success: function(data) {
                $('#freelancerList').html(data);
            }
        });
    }

</script>

 
<?php $__env->stopPush(); ?>
<?php echo $__env->make('_html.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>