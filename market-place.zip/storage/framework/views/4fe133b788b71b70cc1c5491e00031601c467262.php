 
<?php $__env->startSection('title', 'Job|Find Job'); ?> 
<?php $__env->startSection('content'); ?>

<div class="clearfix"></div>

<!-- Title Header Start -->
<section class="inner-header-title" style="background-image:url(<?php echo e(asset('_html/assets/img/banner-10.jpg')); ?>);">
    <div class="container">
        <h1>Find Job</h1>
    </div>
</section>

<!-- bottom form section start -->
<section class="bottom-search-form">
    <div class="container">
        <form class="bt-form" id="searchForm">
            <div class="col-md-4 col-sm-6">
                <input type="text" class="form-control" name="keyword" placeholder="Keyword">
            </div>

            <div class="col-md-4 col-sm-6">
                <input type="text" class="form-control" name="skills" placeholder="Skills">
            </div>

            <div class="col-md-4 col-sm-6">
                <select class="form-control" name="category">
                    <option value="">Search By Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-4 col-sm-6">
                <select class="form-control" name="experience">
                      <option value="">Search By Experience</option>
                      <option value="1">1 Year</option>
                      <option value="2">2 Year</option>
                      <option value="3">3 Year</option>
                      <option value="4">4 + Year</option>
                    </select>
            </div>
            <div class="col-md-4 col-sm-6">
                <select id="location" class="form-control" name="location">
                    <option value="">Choose Location</option>
                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($location->id); ?>"><?php echo e($location->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-4 col-sm-6">
                <input type="text" class="form-control" name="budgetFrom" placeholder="Budget From">
            </div>
            <div class="col-md-4 col-sm-6">
                <input type="text" class="form-control" name="budgetTo" placeholder="Budget To">
            </div>

            <div class="col-md-4 col-sm-6">
                <select id="country" class="form-control" name="country">
                    <option value="">Choose Country</option>
                    <option value="">Bangladesh</option>
                    <option value="">Canade</option>
                    <option value="">USA</option>
                    <option value="">England</option>
                </select>
            </div>

            <div class="col-md-4 col-sm-6">
                <button type="submit" class="btn btn-primary" onclick="searchJob()">Search Job</button>
            </div>
        </form>
    </div>
</section>
<!-- Bottom Search Form Section End -->
<div class="clearfix"></div>
<!-- Title Header End -->

<!-- Manage Company List Start -->
<section class="manage-company gray">
    <div class="container">
        <div class="row">
            <div id="jobList">
    <?php echo $__env->make('_html.ajax.ajaxJob', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
</section>
<!-- Manage Company List End -->
<?php $__env->stopSection(); ?>
 <?php $__env->startPush('scripts'); ?>
<script type="text/javascript">            
    $(document).on('click', '.pagination a', function(event) {
        event.preventDefault();
        var page = $(this).attr('href').split('page=')[1];
        paginageData(page);
    });

    function paginageData(page) {
        $.ajax({
            type: 'POST',
            url: baseUrl + "Job/Read?page=" + page,
            success: function(data) {
                $('#jobList').html(data);
            }
        });
    }

</script>
<script type="text/javascript" src="<?php echo e(asset('_html/pages/jobs.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('_html.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>