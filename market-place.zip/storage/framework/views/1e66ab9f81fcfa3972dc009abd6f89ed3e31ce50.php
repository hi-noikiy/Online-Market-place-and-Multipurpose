<?php $__env->startSection('title','WishList'); ?>
<?php $__env->startSection('chore_content'); ?>
<div class="breadcrumb-wrap">
    <div class="padd10">
        <span typeof="v:Breadcrumb">
        <a  href="<?php echo e(url('chores/admin')); ?>" class="main-home">My account</a></span> &gt; 
        <span typeof="v:Breadcrumb"><a  href="<?php echo e(url('chores/mywishlist')); ?>" class="home">My Wishlist</a></span>
    </div>
</div>
<style>

</style>
<div id="content" class="content-for-account  col-xs-10 col-sm-8 col-lg-8 ">
     <div class="my_box3" style="height:100%">      
          <div class=""> 
               <h6 class="widget-title">
                        <span> 
                       My Wishlist
                        </span>
                </h6>
     
          </div>
          <?php
              $u=Auth::user();
              $wish=App\Wishlist::where('user_id',$u->id)->get();
          ?>
          <?php if($wish): ?>
             <?php $__currentLoopData = $wish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                  $mytask=App\chore::find($wish->ChoSer_id)->first();
              ?>
                <div class="grid_task">
                    <?php if($wish->type==1): ?>
                        <div class="badge badge-success ">Task</div>
                    <?php else: ?> 
                        <div class="badge badge-success ">Service</div>
                    <?php endif; ?>
                    <?php if($mytask->precidance==1): ?>
                        <div class="badge badge-warning ">Featured</div>
                    <?php else: ?> 
                        <div class="badge badge-warning ">Normal</div>
                    <?php endif; ?>
                        
                                
                        <div class="slider_picture">
                        <a href="<?php echo e(url('chores/details/'.$mytask->id)); ?>">
                            <?php
                                $image=App\Image::find($mytask->image_id)->first();
                            ?>
                            <img class="image_sld" src="<?php echo e(asset('uploads/image/'.$image->image)); ?>" width="160" height="160" alt="Oil Change" />
                        </a>
                        </div>
                            
                        <div class="slider_versatile">
                            <?php echo e($mytask->name); ?><br/>
                            <span class="prcs_prcs">$ <?php echo e($mytask->price); ?></span>
                        </div>
                    
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
            <?php endif; ?>
     </div> 
<div class="clear10"></div>
       
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('chore.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>