(function($){
"use strict";

      document.querySelector('.sweet-1').onclick = function(){
        swal("Congratulations!", "You have update successfuly!", "success");
      };
	  
	 document.querySelector('.sweet-3').onclick = function(){
        swal("Good job!", "You have applied for this job!", "success");
      };
	  
})(jQuery);